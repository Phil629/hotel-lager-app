import { generateId } from "../utils";
import React, { useState, useEffect } from 'react';
import type { Product, Order, Supplier } from '../types';
import { StorageService } from '../services/storage';
import { DataService } from '../services/data';
import { Plus, Edit2, Trash2, ShoppingCart, X, Mail, ExternalLink, CheckSquare, Square, Wifi, Settings, Phone, MessageSquare, Search, AlertTriangle, Euro, QrCode, ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';
import emailjs from '@emailjs/browser';
import { Notification, type NotificationType } from '../components/Notification';
import QRCode from "react-qr-code";
import { useSearchParams } from 'react-router-dom';

const CATEGORIES = ['Lebensmittel', 'Getränke', 'Reinigung', 'Büro', 'Sonstiges'];

export const Products: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [suppliers, setSuppliers] = useState<Supplier[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [newProduct, setNewProduct] = useState<Partial<Product>>({
        category: '',
        unit: '',
        stock: 0,
        minStock: 0,
        price: 0,
        autoOrder: false,
        notes: [],
        preferredOrderMethod: 'email'
    });
    const [isCreatingSupplier, setIsCreatingSupplier] = useState(false);
    const [showSupplierDetails, setShowSupplierDetails] = useState(false);
    const [newSupplier, setNewSupplier] = useState<Partial<Supplier>>({
        name: '',
        email: '',
        phone: '',
        contactName: '',
        url: '',
        notes: [],
        emailSubjectTemplate: '',
        emailBodyTemplate: ''
    });
    // isEmailSectionOpen removed as requested
    const [showIoTLink, setShowIoTLink] = useState<{ product: Product, curl: string, powershell: string } | null>(null);
    const [qrTab, setQrTab] = useState<'api' | 'order' | 'stock'>('api');
    const [isOrderEmailExpanded, setIsOrderEmailExpanded] = useState(false);
    const [isCustomCategoryMode, setIsCustomCategoryMode] = useState(false);
    const [isInventoryDetailsOpen, setIsInventoryDetailsOpen] = useState(false);
    const [isEmailTemplateOpen, setIsEmailTemplateOpen] = useState(false);

    const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
    const [orderCart, setOrderCart] = useState<{product: Product, quantity: number}[]>([]);
    const [orderDate, setOrderDate] = useState(new Date().toISOString().split('T')[0]);
    const [orderNotes, setOrderNotes] = useState('');
    const [emailSubject, setEmailSubject] = useState('');
    const [emailBody, setEmailBody] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const [notification, setNotification] = useState<{ message: string, type: NotificationType } | null>(null);
    const [openSettingsId, setOpenSettingsId] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [showLowStockOnly, setShowLowStockOnly] = useState(false);



    // Stock Update Modal (Scan Action)
    const [isStockUpdateModalOpen, setIsStockUpdateModalOpen] = useState(false);
    const [stockUpdateProduct, setStockUpdateProduct] = useState<Product | null>(null);
    const [stockUpdateValue, setStockUpdateValue] = useState<number>(0);

    const [sortConfig, setSortConfig] = useState<{ key: 'name' | 'stock' | null, direction: 'asc' | 'desc' }>({ key: null, direction: 'asc' });
    const [searchParams] = useSearchParams();

    useEffect(() => {
        const handleResize = () => setIsMobile(window.innerWidth < 768);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    useEffect(() => {
        // Load data and then check params
        const init = async () => {
            try {
                await loadSuppliers().catch(e => console.error('Error loading suppliers:', e));
                const loadedProducts = await DataService.getProducts();
                
                // Immediately set products so the UI renders
                setProducts(loadedProducts);

                // Handle URL Actions (QR Scans)
                const action = searchParams.get('action');
                const id = searchParams.get('id');

                if (action && id && loadedProducts.length > 0) {
                    const product = loadedProducts.find(p => p.id === id);
                    if (product) {
                        if (action === 'order') handleOrderClick(product);
                        else if (action === 'stock') {
                            setStockUpdateProduct(product);
                            setStockUpdateValue(product.stock);
                            setIsStockUpdateModalOpen(true);
                        }
                    }
                }

                // Auto-consumption logic in the background
                const runAutoConsumption = async () => {
                    const now = new Date();
                    let updatedAny = false;
                    const updatedProducts = [...loadedProducts];

                    for (let i = 0; i < updatedProducts.length; i++) {
                        const p = updatedProducts[i];
                        if (p.consumptionAmount && p.consumptionPeriod) {
                            try {
                                if (!p.lastConsumptionDate) {
                                    p.lastConsumptionDate = now.toISOString();
                                    await DataService.saveProduct(p);
                                    updatedAny = true;
                                } else {
                                    const lastDate = new Date(p.lastConsumptionDate);
                                    if (isNaN(lastDate.getTime())) continue;
                                    
                                    const diffTime = Math.abs(now.getTime() - lastDate.getTime());
                                    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                                    
                                    let periodsPassed = 0;
                                    if (p.consumptionPeriod === 'day') periodsPassed = diffDays;
                                    else if (p.consumptionPeriod === 'week') periodsPassed = Math.floor(diffDays / 7);

                                    if (periodsPassed > 0) {
                                        const toDeduct = periodsPassed * p.consumptionAmount;
                                        p.stock = Math.max(0, p.stock - toDeduct);
                                        
                                        const newLastDate = new Date(lastDate);
                                        if (p.consumptionPeriod === 'day') newLastDate.setDate(newLastDate.getDate() + periodsPassed);
                                        else if (p.consumptionPeriod === 'week') newLastDate.setDate(newLastDate.getDate() + (periodsPassed * 7));
                                        
                                        p.lastConsumptionDate = newLastDate.toISOString();
                                        await DataService.saveProduct(p);
                                        updatedAny = true;
                                    }
                                }
                            } catch (err) {
                                console.error('Failed to auto-consume product', p.id, err);
                            }
                        }
                    }

                    if (updatedAny) setProducts(updatedProducts);
                };
                
                runAutoConsumption();
            } catch (error) {
                console.error('Fatal init error:', error);
            }
        };
        
        init();
    }, [searchParams]); // Re-run if params change (though mostly on mount)

    const loadProducts = async () => {
        const data = await DataService.getProducts();
        setProducts(data);
    };

    const handleStockUpdate = async (product: Product, newStock: number) => {
        const updatedProduct = { ...product, stock: newStock };
        // Optimistic update
        setProducts(products.map(p => p.id === product.id ? updatedProduct : p));
        // Save to backend
        await DataService.updateProduct(updatedProduct);
    };

    const loadSuppliers = async () => {
        const data = await DataService.getSuppliers();
        setSuppliers(data);
    };

    const handleDeleteClick = (id: string) => {
        setDeleteConfirmId(id);
    };

    const confirmDelete = async () => {
        if (deleteConfirmId) {
            setIsLoading(true);
            await DataService.deleteProduct(deleteConfirmId);
            await loadProducts();
            setIsLoading(false);
            setDeleteConfirmId(null);
        }
    };

    const handleEdit = (product: Product) => {
        setNewProduct(product);
        setEditingId(product.id);
        // setIsEmailSectionOpen(!!product.emailOrderAddress); // Removed
        setIsCustomCategoryMode(!CATEGORIES.includes(product.category || ''));
        setIsModalOpen(true);
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newProduct.name) return;

        let finalSupplierId = newProduct.supplierId;

        // Create new supplier if in creation mode
        if (isCreatingSupplier && newSupplier.name) {
            try {
                const id = generateId();
                const supplier: Supplier = {
                    id,
                    name: newSupplier.name || 'Unbekannt',
                    email: newSupplier.email || '',
                    phone: newSupplier.phone,
                    contactName: newSupplier.contactName,
                    url: newSupplier.url,
                    notes: newSupplier.notes,
                    emailSubjectTemplate: newSupplier.emailSubjectTemplate,
                    emailBodyTemplate: newSupplier.emailBodyTemplate
                };
                await DataService.saveSupplier(supplier);
                finalSupplierId = id;
                await loadSuppliers(); // Refresh list

                // If product email is empty, use the new supplier's email
                if (!newProduct.emailOrderAddress) {
                    newProduct.emailOrderAddress = newSupplier.email;
                }
            } catch (error) {
                console.error("Failed to create supplier:", error);
                setNotification({ message: 'Fehler beim Anlegen des Lieferanten.', type: 'error' });
                return;
            }
        }

        const productData: Product = {
            id: editingId || generateId(),
            name: newProduct.name,
            category: newProduct.category,
            stock: Number(newProduct.stock) || 0,
            minStock: Number(newProduct.minStock) || 0,
            price: Number(newProduct.price) || 0,
            unit: newProduct.unit || 'Stück',
            orderUrl: newProduct.orderUrl,
            image: newProduct.image,
            supplierId: finalSupplierId,
            emailOrderAddress: newProduct.emailOrderAddress,
            emailOrderSubject: newProduct.emailOrderSubject,
            emailOrderBody: newProduct.emailOrderBody,
            autoOrder: newProduct.autoOrder,
            supplierPhone: newProduct.supplierPhone,
            notes: newProduct.notes,
            preferredOrderMethod: newProduct.preferredOrderMethod,
            consumptionAmount: newProduct.consumptionAmount,
            consumptionPeriod: newProduct.consumptionPeriod,
            lastConsumptionDate: newProduct.lastConsumptionDate
        };

        setIsLoading(true);
        try {
            await DataService.saveProduct(productData);
            await loadProducts();
            closeModal();
        } finally {
            setIsLoading(false);
        }
    };

    const generateEmailTemplate = (cart: {product: Product, quantity: number}[]) => {
        if (cart.length === 0) return { subject: '', body: '' };
        const mainProduct = cart[0].product;
        const supplier = suppliers.find(s => s.id === mainProduct.supplierId);
        
        let subject = supplier?.emailSubjectTemplate || mainProduct.emailOrderSubject || `Bestellung: {product_name}`;
        let body = supplier?.emailBodyTemplate || mainProduct.emailOrderBody || `Sehr geehrte Damen und Herren,\n\nbitte liefern Sie {quantity}x {product_name} ({unit}).\n\nMit freundlichen Grüßen\nHotel Rezeption`;

        if (cart.length === 1) {
            subject = subject.replace(/{product_name}/g, mainProduct.name).replace(/{quantity}/g, cart[0].quantity.toString()).replace(/{unit}/g, mainProduct.unit || '');
            body = body.replace(/{product_name}/g, mainProduct.name).replace(/{quantity}/g, cart[0].quantity.toString()).replace(/{unit}/g, mainProduct.unit || '');
        } else {
            const listSubjectInfo = cart.length + " Produkte";
            const listBodyInfo = '\n' + cart.map(c => `- ${c.quantity}x ${c.product.name} (${c.product.unit || ''})`).join('\n');
            
            subject = subject.replace(/{quantity}x?\s*{product_name}(?:\s*\({unit}\))?|{product_name}/g, listSubjectInfo);
            body = body.replace(/{quantity}x?\s*{product_name}(?:\s*\({unit}\))?|{product_name}/g, listBodyInfo);
        }
        return { subject, body };
    };

    const handleOrderClick = (product: Product) => {
        const initialCart = [{ product, quantity: 1 }];
        setOrderCart(initialCart);
        setOrderDate(new Date().toISOString().split('T')[0]);
        setOrderNotes('');

        const { subject, body } = generateEmailTemplate(initialCart);
        setEmailSubject(subject);
        setEmailBody(body);
        setIsOrderEmailExpanded(product.preferredOrderMethod === 'email');
        setIsOrderModalOpen(true);
    };

    const addToCart = (product: Product) => {
        setOrderCart(prev => {
            const newCart = [...prev, { product, quantity: 1 }];
            const { subject, body } = generateEmailTemplate(newCart);
            setEmailSubject(subject);
            setEmailBody(body);
            return newCart;
        });
    };

    const updateCartQuantity = (index: number, quantity: number) => {
        setOrderCart(prev => {
            const newCart = prev.map((c, i) => i === index ? { ...c, quantity } : c);
            const { subject, body } = generateEmailTemplate(newCart);
            setEmailSubject(subject);
            setEmailBody(body);
            return newCart;
        });
    };

    const removeFromCart = (index: number) => {
        setOrderCart(prev => {
            const newCart = prev.filter((_, i) => i !== index);
            const { subject, body } = generateEmailTemplate(newCart);
            setEmailSubject(subject);
            setEmailBody(body);
            return newCart;
        });
    };

    const handleCreateOrder = async (e: React.FormEvent) => {
        e.preventDefault();
        if (orderCart.length === 0) return;

        setIsLoading(true);
        try {
            const mainProduct = orderCart[0].product;
            if (mainProduct.autoOrder && mainProduct.emailOrderAddress) {
                const settings = StorageService.getSettings();
                if (!settings.serviceId || !settings.templateId || !settings.publicKey) {
                    setNotification({ message: 'Fehler: EmailJS ist nicht konfiguriert.', type: 'error' });
                    setIsLoading(false);
                    return;
                }
                const templateParams = {
                    to_email: mainProduct.emailOrderAddress,
                    subject: emailSubject,
                    message: emailBody,
                    product_name: orderCart.length > 1 ? orderCart.length + " Produkte" : mainProduct.name,
                    quantity: orderCart.length > 1 ? "" : orderCart[0].quantity,
                    unit: orderCart.length > 1 ? "" : mainProduct.unit
                };
                await emailjs.send(settings.serviceId, settings.templateId, templateParams, settings.publicKey);
                setNotification({ message: 'Bestellung wurde automatisch per E-Mail versendet!', type: 'success' });
            }

            for (const item of orderCart) {
                const newOrder: Order = {
                    id: generateId(),
                    date: new Date(orderDate).toISOString(),
                    productName: item.product.name,
                    quantity: item.quantity,
                    status: 'open',
                    productImage: item.product.image,
                    supplierEmail: item.product.emailOrderAddress,
                    supplierPhone: item.product.supplierPhone,
                    notes: orderNotes
                };
                await DataService.saveOrder(newOrder);
            }

            setIsOrderModalOpen(false);
            setOrderCart([]);
            if (!mainProduct.autoOrder) {
                setNotification({ message: 'Bestellung erfolgreich angelegt!', type: 'success' });
            }
        } catch (error) {
            console.error('Order Error:', error);
            setNotification({ message: 'Fehler beim Anlegen der Bestellung.', type: 'error' });
        } finally {
            setIsLoading(false);
        }
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setNewProduct({ category: '', unit: '', stock: 0, minStock: 0, price: 0, autoOrder: false, notes: [], preferredOrderMethod: 'email' });
        setEditingId(null);
        // setIsEmailSectionOpen(false); // Removed
        setIsCustomCategoryMode(false);
        setIsInventoryDetailsOpen(false);
        setIsEmailTemplateOpen(false);
    };

    const getIoTLink = (product: Product) => {
        const settings = StorageService.getSettings();
        // Return structure even if settings are missing, for QR codes
        if (!settings.supabaseUrl || !settings.supabaseKey) {
            return { product, curl: '', powershell: '' };
        }

        // Ensure no trailing slash in URL
        const baseUrl = settings.supabaseUrl.replace(/\/$/, '');
        const url = `${baseUrl}/rest/v1/orders`;

        const bodyObj = {
            product_name: product.name,
            quantity: 1,
            status: 'open',
            product_image: product.image
        };
        const bodyJson = JSON.stringify(bodyObj);

        // Escape single quotes for shell (curl): ' becomes '\''
        const bodyJsonCurl = bodyJson.replace(/'/g, "'\\''");

        const curl = `curl -X POST '${url}' \\
  -H "apikey: ${settings.supabaseKey}" \\
  -H "Authorization: Bearer ${settings.supabaseKey}" \\
  -H "Content-Type: application/json" \\
  -d '${bodyJsonCurl}'`;

        // Escape single quotes for PowerShell: ' becomes ''
        const bodyJsonPwsh = bodyJson.replace(/'/g, "''");

        // Robust PowerShell command:
        const powershell = `$h=@{"apikey"="${settings.supabaseKey}";"Authorization"="Bearer ${settings.supabaseKey}"}; Invoke-RestMethod -Uri "${url}" -Method Post -Headers $h -ContentType "application/json" -Body ([System.Text.Encoding]::UTF8.GetBytes('${bodyJsonPwsh}'))`;

        return { product, curl, powershell };
    };

    const prepareEmailLink = (type: 'mailto' | 'gmail') => {
        if (orderCart.length === 0 || !orderCart[0].product.emailOrderAddress) return;

        const mainProduct = orderCart[0].product;
        const encodedSubject = encodeURIComponent(emailSubject);
        const encodedBody = encodeURIComponent(emailBody);

        if (type === 'gmail') {
            window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${mainProduct.emailOrderAddress}&su=${encodedSubject}&body=${encodedBody}`, '_blank');
        } else {
            window.location.href = `mailto:${mainProduct.emailOrderAddress}?subject=${encodedSubject}&body=${encodedBody}`;
        }
    };

    const handleSort = (key: 'name' | 'stock') => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const filteredProducts = products.filter(p => {
        const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesLowStock = showLowStockOnly ? p.stock <= (p.minStock || 0) : true;
        return matchesSearch && matchesLowStock;
    }).sort((a, b) => {
        if (!sortConfig.key) return 0;

        if (sortConfig.key === 'name') {
            return sortConfig.direction === 'asc'
                ? a.name.localeCompare(b.name)
                : b.name.localeCompare(a.name);
        }

        if (sortConfig.key === 'stock') {
            return sortConfig.direction === 'asc'
                ? a.stock - b.stock
                : b.stock - a.stock;
        }

        return 0;
    });

    const totalValue = products.reduce((sum, p) => sum + (p.stock * (p.price || 0)), 0);
    const lowStockCount = products.filter(p => p.stock <= (p.minStock || 0)).length;

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-md)' }}>
                <h2 style={{ fontSize: 'var(--font-size-2xl)', margin: 0 }}>Produkte</h2>
                <button
                    onClick={() => setIsModalOpen(true)}
                    style={{
                        backgroundColor: 'var(--color-primary)',
                        color: 'white',
                        border: 'none',
                        padding: 'var(--spacing-sm) var(--spacing-md)',
                        borderRadius: 'var(--radius-md)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 'var(--spacing-sm)',
                        fontWeight: 500
                    }}
                >
                    <Plus size={20} />
                    Neues Produkt
                </button>
            </div>

            {/* Dashboard Cards */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                gap: 'var(--spacing-md)',
                marginBottom: 'var(--spacing-xl)'
            }}>
                <div
                    onClick={() => setShowLowStockOnly(false)}
                    style={{ backgroundColor: 'var(--color-surface)', padding: 'var(--spacing-md)', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)', cursor: 'pointer' }}
                >
                    <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)', marginBottom: '4px' }}>Produkte Gesamt</div>
                    <div style={{ fontSize: '24px', fontWeight: 700 }}>{products.length}</div>
                </div>
                <div
                    onClick={() => setShowLowStockOnly(!showLowStockOnly)}
                    style={{
                        backgroundColor: lowStockCount > 0 ? '#FEF2F2' : 'var(--color-surface)',
                        padding: 'var(--spacing-md)',
                        borderRadius: 'var(--radius-md)',
                        border: lowStockCount > 0 ? '1px solid #FECACA' : '1px solid var(--color-border)',
                        boxShadow: 'var(--shadow-sm)',
                        cursor: 'pointer'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: lowStockCount > 0 ? '#DC2626' : 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)', marginBottom: '4px' }}>
                        <AlertTriangle size={16} /> Niedriger Bestand
                    </div>
                    <div style={{ fontSize: '24px', fontWeight: 700, color: lowStockCount > 0 ? '#DC2626' : 'inherit' }}>{lowStockCount}</div>
                </div>
                <div style={{ backgroundColor: 'var(--color-surface)', padding: 'var(--spacing-md)', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)', marginBottom: '4px' }}>
                        <Euro size={16} /> Lagerwert (Netto)
                    </div>
                    <div style={{ fontSize: '24px', fontWeight: 700 }}>{totalValue.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}</div>
                </div>
            </div>

            <div style={{ display: 'flex', gap: 'var(--spacing-md)', marginBottom: 'var(--spacing-lg)' }}>
                <div style={{ position: 'relative', flex: 1 }}>
                    <Search size={20} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-muted)' }} />
                    <input
                        type="text"
                        placeholder="Produkte suchen..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        style={{
                            width: '100%',
                            padding: '10px 10px 10px 40px',
                            borderRadius: 'var(--radius-md)',
                            border: '1px solid var(--color-border)',
                            fontSize: 'var(--font-size-md)',
                            backgroundColor: 'var(--color-surface)'
                        }}
                    />
                </div>
                <button
                    onClick={() => setShowLowStockOnly(!showLowStockOnly)}
                    style={{
                        padding: '0 20px',
                        borderRadius: 'var(--radius-md)',
                        border: showLowStockOnly ? '1px solid #DC2626' : '1px solid var(--color-border)',
                        backgroundColor: showLowStockOnly ? '#FEF2F2' : 'var(--color-surface)',
                        color: showLowStockOnly ? '#DC2626' : 'var(--color-text-main)',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontWeight: 500,
                        whiteSpace: 'nowrap'
                    }}
                >
                    <AlertTriangle size={18} />
                    {showLowStockOnly ? 'Alle anzeigen' : 'Kritischer Bestand'}
                </button>
            </div>

            {
                isMobile ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
                        {filteredProducts.map(product => (
                            <div key={product.id} style={{
                                backgroundColor: 'var(--color-surface)',
                                borderRadius: 'var(--radius-md)',
                                padding: 'var(--spacing-md)',
                                boxShadow: 'var(--shadow-sm)',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: 'var(--spacing-sm)'
                            }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                    <div style={{ display: 'flex', gap: 'var(--spacing-md)', alignItems: 'center' }}>
                                        {product.image && (
                                            <img
                                                src={product.image}
                                                alt={product.name}
                                                style={{ width: '60px', height: '60px', objectFit: 'cover', borderRadius: 'var(--radius-sm)' }}
                                            />
                                        )}
                                        <div>
                                            <div style={{ fontWeight: 600, fontSize: 'var(--font-size-lg)' }}>{product.name}</div>
                                            <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>{product.category}</div>
                                            {(() => {
                                                const supplier = suppliers.find(s => s.id === product.supplierId);
                                                if (supplier?.notes) {
                                                    return (supplier.notes.filter(n => n.showOnOpenOrders) || []).map(n => (
                                                        <div key={n.id} style={{ backgroundColor: '#fff3cd', color: '#856404', padding: '4px 8px', borderRadius: 'var(--radius-sm)', marginTop: '4px', border: '1px solid #ffeeba', fontSize: '12px' }}>
                                                            <strong>Lieferant:</strong> {n.text}
                                                        </div>
                                                    ));
                                                }
                                                return null;
                                            })()}
                                            {(product.notes || []).filter(n => n.showOnOpenOrders).map(n => (
                                                <div key={n.id} style={{ backgroundColor: '#fff3cd', color: '#856404', padding: '4px 8px', borderRadius: 'var(--radius-sm)', marginTop: '4px', border: '1px solid #ffeeba', fontSize: '12px' }}>
                                                    <strong>Produktnotiz:</strong> {n.text}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div style={{ textAlign: 'right' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px', justifyContent: 'flex-end' }}>
                                            <button
                                                onClick={() => handleStockUpdate(product, Math.max(0, product.stock - 1))}
                                                style={{ width: '28px', height: '28px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', background: 'var(--color-background)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '16px', color: 'var(--color-text-muted)' }}
                                            >−</button>
                                            <input
                                                type="number"
                                                value={product.stock}
                                                min={0}
                                                onChange={e => handleStockUpdate(product, Math.max(0, parseInt(e.target.value) || 0))}
                                                style={{
                                                    width: '52px',
                                                    textAlign: 'center',
                                                    fontSize: 'var(--font-size-xl)',
                                                    fontWeight: 700,
                                                    border: '1px solid var(--color-border)',
                                                    borderRadius: 'var(--radius-sm)',
                                                    padding: '2px 4px',
                                                    color: product.stock <= (product.minStock || 0) ? 'var(--color-danger)' : 'inherit',
                                                    background: 'var(--color-surface)'
                                                }}
                                            />
                                            <button
                                                onClick={() => handleStockUpdate(product, product.stock + 1)}
                                                style={{ width: '28px', height: '28px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', background: 'var(--color-background)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '16px', color: 'var(--color-primary)' }}
                                            >+</button>
                                        </div>
                                        <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', textAlign: 'center', marginTop: '2px' }}>{product.unit}</div>
                                        {product.price && (
                                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', marginTop: '4px' }}>
                                                Ø {(product.stock * product.price).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'var(--spacing-xs)', paddingTop: 'var(--spacing-sm)', borderTop: '1px solid var(--color-border)' }}>
                                    <div style={{ display: 'flex', gap: 'var(--spacing-xs)' }}>
                                        {product.orderUrl && (
                                            <a href={product.orderUrl} target="_blank" rel="noopener noreferrer"
                                                style={{ padding: '6px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-background)', color: 'var(--color-primary)' }}>
                                                <ExternalLink size={18} />
                                            </a>
                                        )}
                                        {product.emailOrderAddress && (
                                            <div style={{ padding: '6px', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-background)', color: 'var(--color-text-muted)' }}>
                                                <Mail size={18} />
                                            </div>
                                        )}
                                    </div>
                                    <div style={{ display: 'flex', gap: 'var(--spacing-sm)' }}>
                                        <button onClick={() => {
                                            const links = getIoTLink(product);
                                            // Ensure links is not null before setting state
                                            if (links) {
                                                setShowIoTLink(links);
                                                setQrTab('api'); // Reset to first tab
                                            } else {
                                                setNotification({ message: 'Bitte konfigurieren Sie zuerst Supabase in den Einstellungen.', type: 'error' });
                                            }
                                        }} style={{
                                            padding: '8px',
                                            borderRadius: 'var(--radius-md)',
                                            border: '1px solid var(--color-border)',
                                            background: 'white',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '4px'
                                        }}
                                            title="IoT / QR Code"
                                        >
                                            <QrCode size={18} />
                                        </button>
                                        <button onClick={() => handleEdit(product)} style={{ padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', background: 'white', cursor: 'pointer' }}>
                                            <Edit2 size={18} />
                                        </button>
                                        <button onClick={() => handleDeleteClick(product.id)} style={{ padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', background: 'white', color: 'var(--color-danger)', cursor: 'pointer' }}>
                                            <Trash2 size={18} />
                                        </button>
                                        <button onClick={() => handleOrderClick(product)} style={{
                                            padding: '8px 16px', borderRadius: 'var(--radius-md)', border: 'none', background: 'var(--color-primary)', color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px'
                                        }}>
                                            <ShoppingCart size={18} /> Bestellen
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div style={{
                        backgroundColor: 'var(--color-surface)',
                        borderRadius: 'var(--radius-lg)',
                        boxShadow: 'var(--shadow-sm)'
                    }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                            <thead style={{ backgroundColor: 'var(--color-background)', borderBottom: '1px solid var(--color-border)' }}>
                                <tr>
                                    <th style={{ padding: 'var(--spacing-md)', textAlign: 'left', color: 'var(--color-text-muted)', fontWeight: 600 }}>Bild</th>
                                    <th
                                        onClick={() => handleSort('name')}
                                        style={{ padding: 'var(--spacing-md)', textAlign: 'left', color: 'var(--color-text-muted)', fontWeight: 600, cursor: 'pointer' }}
                                    >
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                            Name {sortConfig.key === 'name' ? (sortConfig.direction === 'asc' ? <ArrowUp size={16} /> : <ArrowDown size={16} />) : <ArrowUpDown size={16} style={{ opacity: 0.3 }} />}
                                        </div>
                                    </th>
                                    <th
                                        onClick={() => handleSort('stock')}
                                        style={{ padding: 'var(--spacing-md)', textAlign: 'right', color: 'var(--color-text-muted)', fontWeight: 600, cursor: 'pointer' }}
                                    >
                                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '4px' }}>
                                            Bestand & Wert {sortConfig.key === 'stock' ? (sortConfig.direction === 'asc' ? <ArrowUp size={16} /> : <ArrowDown size={16} />) : <ArrowUpDown size={16} style={{ opacity: 0.3 }} />}
                                        </div>
                                    </th>
                                    <th style={{ padding: 'var(--spacing-md)', textAlign: 'left', color: 'var(--color-text-muted)', fontWeight: 600 }}>Kontakt / Links</th>
                                    <th style={{ padding: 'var(--spacing-md)', textAlign: 'center', color: 'var(--color-text-muted)', fontWeight: 600 }}>Bestellen</th>
                                    <th style={{ padding: 'var(--spacing-md)', textAlign: 'right', color: 'var(--color-text-muted)', fontWeight: 600 }}></th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredProducts.map((product, index) => {
                                    const isLastRows = index >= filteredProducts.length - 2 && filteredProducts.length > 3;
                                    return (
                                        <tr key={product.id} style={{ borderBottom: '1px solid var(--color-border)' }}>
                                            <td style={{ padding: 'var(--spacing-md)' }}>
                                                {product.image && (
                                                    <img
                                                        src={product.image}
                                                        alt={product.name}
                                                        style={{ width: '40px', height: '40px', objectFit: 'cover', borderRadius: 'var(--radius-sm)' }}
                                                    />
                                                )}
                                            </td>
                                            <td style={{ padding: 'var(--spacing-md)' }}>
                                                <div style={{ fontWeight: 500, fontSize: 'var(--font-size-lg)' }}>{product.name}</div>
                                                <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>
                                                    {product.price ? product.price.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }) : '-'} / {product.unit}
                                                </div>
                                                {(() => {
                                                    const supplier = suppliers.find(s => s.id === product.supplierId);
                                                    if (supplier?.notes) {
                                                        return (supplier.notes.filter(n => n.showOnOpenOrders) || []).map(n => (
                                                            <div key={n.id} style={{ backgroundColor: '#fff3cd', color: '#856404', padding: '4px 8px', borderRadius: 'var(--radius-sm)', marginTop: '4px', border: '1px solid #ffeeba', fontSize: '12px' }}>
                                                                <strong>Lieferant:</strong> {n.text}
                                                            </div>
                                                        ));
                                                    }
                                                    return null;
                                                })()}
                                                {(product.notes || []).filter(n => n.showOnOpenOrders).map(n => (
                                                    <div key={n.id} style={{ backgroundColor: '#fff3cd', color: '#856404', padding: '4px 8px', borderRadius: 'var(--radius-sm)', marginTop: '4px', border: '1px solid #ffeeba', fontSize: '12px' }}>
                                                        <strong>Produktnotiz:</strong> {n.text}
                                                    </div>
                                                ))}
                                            </td>
                                            <td style={{ padding: 'var(--spacing-md)', textAlign: 'right' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', justifyContent: 'flex-end' }}>
                                                    <button
                                                        onClick={() => handleStockUpdate(product, Math.max(0, product.stock - 1))}
                                                        style={{ width: '26px', height: '26px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', background: 'var(--color-background)', cursor: 'pointer', fontWeight: 700, fontSize: '15px', color: 'var(--color-text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                                    >−</button>
                                                    <input
                                                        type="number"
                                                        value={product.stock}
                                                        min={0}
                                                        onChange={e => handleStockUpdate(product, Math.max(0, parseInt(e.target.value) || 0))}
                                                        style={{
                                                            width: '56px',
                                                            textAlign: 'center',
                                                            fontSize: 'var(--font-size-lg)',
                                                            fontWeight: 700,
                                                            border: '1px solid var(--color-border)',
                                                            borderRadius: 'var(--radius-sm)',
                                                            padding: '2px 4px',
                                                            color: product.stock <= (product.minStock || 0) ? 'var(--color-danger)' : 'inherit',
                                                            background: 'var(--color-surface)'
                                                        }}
                                                    />
                                                    <button
                                                        onClick={() => handleStockUpdate(product, product.stock + 1)}
                                                        style={{ width: '26px', height: '26px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', background: 'var(--color-background)', cursor: 'pointer', fontWeight: 700, fontSize: '15px', color: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                                    >+</button>
                                                </div>
                                                <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', textAlign: 'center', marginTop: '2px' }}>{product.unit}</div>
                                                {product.price && (
                                                    <div style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', marginTop: '4px', textAlign: 'center' }}>
                                                        = {(product.stock * product.price).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })}
                                                    </div>
                                                )}
                                            </td>
                                            <td style={{ padding: 'var(--spacing-md)' }}>
                                                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                                                    {product.orderUrl && (
                                                        <a href={product.orderUrl} target="_blank" rel="noopener noreferrer"
                                                            style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--color-primary)', textDecoration: 'none', fontSize: 'var(--font-size-sm)' }}>
                                                            <ExternalLink size={14} /> Link
                                                        </a>
                                                    )}
                                                    {product.emailOrderAddress && (
                                                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>
                                                            <Mail size={14} /> {product.emailOrderAddress}
                                                        </div>
                                                    )}
                                                    {product.supplierPhone && (
                                                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>
                                                            <Phone size={14} /> {product.supplierPhone}
                                                        </div>
                                                    )}
                                                </div>
                                            </td>
                                            <td style={{ padding: 'var(--spacing-md)', textAlign: 'center' }}>
                                                <button
                                                    onClick={() => handleOrderClick(product)}
                                                    style={{
                                                        backgroundColor: 'var(--color-primary)',
                                                        color: 'white',
                                                        border: 'none',
                                                        padding: '8px 16px',
                                                        borderRadius: 'var(--radius-md)',
                                                        cursor: 'pointer',
                                                        display: 'inline-flex',
                                                        alignItems: 'center',
                                                        gap: '6px',
                                                        fontWeight: 500,
                                                        boxShadow: 'var(--shadow-sm)'
                                                    }}
                                                >
                                                    <ShoppingCart size={18} />
                                                    Bestellen
                                                </button>
                                            </td>
                                            <td style={{ padding: 'var(--spacing-md)', textAlign: 'right', position: 'relative' }}>
                                                <button
                                                    onClick={() => setOpenSettingsId(openSettingsId === product.id ? null : product.id)}
                                                    style={{
                                                        background: 'none',
                                                        border: 'none',
                                                        color: 'var(--color-text-muted)',
                                                        padding: '8px',
                                                        borderRadius: 'var(--radius-md)',
                                                        cursor: 'pointer',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center'
                                                    }}
                                                >
                                                    <Settings size={20} />
                                                </button>

                                                {openSettingsId === product.id && (
                                                    <>
                                                        <div
                                                            style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 10 }}
                                                            onClick={() => setOpenSettingsId(null)}
                                                        />
                                                        <div style={{
                                                            position: 'absolute',
                                                            right: 'var(--spacing-md)',
                                                            ...(isLastRows
                                                                ? { bottom: '100%', marginBottom: '4px' }
                                                                : { top: '100%', marginTop: '4px' }
                                                            ),
                                                            backgroundColor: 'var(--color-surface)',
                                                            borderRadius: 'var(--radius-md)',
                                                            boxShadow: 'var(--shadow-lg)',
                                                            border: '1px solid var(--color-border)',
                                                            zIndex: 20,
                                                            minWidth: '160px',
                                                            overflow: 'hidden'
                                                        }}>
                                                            <button
                                                                onClick={() => {
                                                                    const links = getIoTLink(product);
                                                                    // Ensure links is not null before setting state
                                                                    if (links) {
                                                                        setShowIoTLink(links);
                                                                        setQrTab('api'); // Reset to first tab
                                                                    } else {
                                                                        setNotification({ message: 'Bitte konfigurieren Sie zuerst Supabase in den Einstellungen.', type: 'error' });
                                                                    }
                                                                    setOpenSettingsId(null);
                                                                }}
                                                                style={{
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: '8px',
                                                                    width: '100%',
                                                                    padding: '12px 16px',
                                                                    border: 'none',
                                                                    background: 'none',
                                                                    textAlign: 'left',
                                                                    cursor: 'pointer',
                                                                    color: 'var(--color-text-main)',
                                                                    fontSize: 'var(--font-size-md)'
                                                                }}
                                                            >
                                                                <QrCode size={16} />
                                                                IoT / QR Code
                                                            </button>
                                                            <button
                                                                onClick={() => {
                                                                    handleEdit(product);
                                                                    setOpenSettingsId(null);
                                                                }}
                                                                style={{
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: '8px',
                                                                    width: '100%',
                                                                    padding: '10px 16px',
                                                                    border: 'none',
                                                                    background: 'none',
                                                                    textAlign: 'left',
                                                                    cursor: 'pointer',
                                                                    color: 'var(--color-text-main)',
                                                                    fontSize: 'var(--font-size-sm)'
                                                                }}
                                                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--color-background)'}
                                                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                                                            >
                                                                <Edit2 size={16} /> Bearbeiten
                                                            </button>
                                                            <button
                                                                onClick={() => {
                                                                    const links = getIoTLink(product);
                                                                    if (links) setShowIoTLink(links);
                                                                    else setNotification({ message: 'Bitte konfigurieren Sie zuerst Supabase in den Einstellungen.', type: 'error' });
                                                                    setOpenSettingsId(null);
                                                                }}
                                                                style={{
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: '8px',
                                                                    width: '100%',
                                                                    padding: '10px 16px',
                                                                    border: 'none',
                                                                    background: 'none',
                                                                    textAlign: 'left',
                                                                    cursor: 'pointer',
                                                                    color: 'var(--color-text-main)',
                                                                    fontSize: 'var(--font-size-sm)'
                                                                }}
                                                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--color-background)'}
                                                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                                                            >
                                                                <Wifi size={16} /> IoT Link
                                                            </button>
                                                            <div style={{ borderTop: '1px solid var(--color-border)', margin: '4px 0' }} />
                                                            <button
                                                                onClick={() => {
                                                                    handleDeleteClick(product.id);
                                                                    setOpenSettingsId(null);
                                                                }}
                                                                style={{
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: '8px',
                                                                    width: '100%',
                                                                    padding: '10px 16px',
                                                                    border: 'none',
                                                                    background: 'none',
                                                                    textAlign: 'left',
                                                                    cursor: 'pointer',
                                                                    color: 'var(--color-danger)',
                                                                    fontSize: 'var(--font-size-sm)'
                                                                }}
                                                                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--color-background)'}
                                                                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                                                            >
                                                                <Trash2 size={16} /> Löschen
                                                            </button>
                                                        </div>
                                                    </>
                                                )
                                                }
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table >
                    </div >
                )
            }

            {/* IoT Link Modal */}
            {
                showIoTLink && (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.5)',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        zIndex: 1100
                    }}>
                        <div style={{
                            backgroundColor: 'var(--color-surface)',
                            padding: 'var(--spacing-xl)',
                            borderRadius: 'var(--radius-lg)',
                            width: '100%',
                            maxWidth: '600px',
                            boxShadow: 'var(--shadow-lg)'
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-md)' }}>
                                <h3 style={{ margin: 0 }}>IoT Button Konfiguration</h3>
                                <button onClick={() => setShowIoTLink(null)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}><X size={24} /></button>
                            </div>
                            <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', marginBottom: 'var(--spacing-md)' }}>
                                Nutzen Sie den CURL-Befehl für den IoT Button. Zum Testen am Windows-PC nutzen Sie den PowerShell-Befehl.
                            </p>

                            <div style={{ marginBottom: 'var(--spacing-md)' }}>
                                <strong style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)' }}>Für Shelly Button / IoT Gerät (CURL):</strong>
                                <pre style={{
                                    backgroundColor: 'var(--color-background)',
                                    padding: 'var(--spacing-md)',
                                    borderRadius: 'var(--radius-md)',
                                    overflowX: 'auto',
                                    fontSize: '12px',
                                    fontFamily: 'monospace',
                                    whiteSpace: 'pre-wrap',
                                    margin: 0
                                }}>
                                    {showIoTLink.curl}
                                </pre>
                            </div>

                            <div>
                                <strong style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)' }}>Zum Testen in Windows PowerShell:</strong>
                                <pre style={{
                                    backgroundColor: 'var(--color-background)',
                                    padding: 'var(--spacing-md)',
                                    borderRadius: 'var(--radius-md)',
                                    overflowX: 'auto',
                                    fontSize: '12px',
                                    fontFamily: 'monospace',
                                    whiteSpace: 'pre-wrap',
                                    margin: 0
                                }}>
                                    {showIoTLink.powershell}
                                </pre>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'var(--spacing-md)' }}>
                                <button
                                    onClick={() => setShowIoTLink(null)}
                                    style={{
                                        padding: 'var(--spacing-sm) var(--spacing-md)',
                                        borderRadius: 'var(--radius-md)',
                                        border: 'none',
                                        backgroundColor: 'var(--color-primary)',
                                        color: 'white'
                                    }}
                                >
                                    Schließen
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {
                isModalOpen && (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.5)',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        zIndex: 1000,
                        overflowY: 'auto'
                    }}>
                        <div style={{
                            backgroundColor: 'var(--color-surface)',
                            padding: 'var(--spacing-xl)',
                            borderRadius: 'var(--radius-lg)',
                            width: '100%',
                            maxWidth: '500px',
                            boxShadow: 'var(--shadow-lg)',
                            maxHeight: '90vh',
                            overflowY: 'auto'
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-lg)' }}>
                                <h3 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>{editingId ? 'Produkt bearbeiten' : 'Neues Produkt anlegen'}</h3>
                                <button onClick={closeModal} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                                    <X size={24} />
                                </button>
                            </div>

                            <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Name</label>
                                    <input
                                        required
                                        value={newProduct.name || ''}
                                        onChange={e => setNewProduct({ ...newProduct, name: e.target.value })}
                                        style={{
                                            width: '100%',
                                            padding: 'var(--spacing-sm)',
                                            borderRadius: 'var(--radius-sm)',
                                            border: !newProduct.name ? '1px solid var(--color-error)' : '1px solid var(--color-border)'
                                        }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Produktnummer</label>
                                    <input
                                        value={newProduct.productNumber || ''}
                                        onChange={e => setNewProduct({ ...newProduct, productNumber: e.target.value })}
                                        placeholder="z.B. 12345-AB"
                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                    />
                                </div>





                                <div>
                                    <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>
                                        Lieferant
                                        {isCreatingSupplier && (
                                            <button
                                                type="button"
                                                onClick={() => setIsCreatingSupplier(false)}
                                                style={{ border: 'none', background: 'none', color: 'var(--color-primary)', cursor: 'pointer', fontSize: 'var(--font-size-xs)' }}
                                            >
                                                Abbrechen
                                            </button>
                                        )}
                                    </label>

                                    {!isCreatingSupplier ? (
                                        <div style={{ display: 'flex', gap: '8px' }}>
                                            <select
                                                value={newProduct.supplierId || ''}
                                                onChange={e => {
                                                    const supplierId = e.target.value;
                                                    const supplier = suppliers.find(s => s.id === supplierId);
                                                    setNewProduct({
                                                        ...newProduct,
                                                        supplierId: supplierId || undefined,
                                                        emailOrderAddress: supplier ? supplier.email : '',
                                                        supplierPhone: supplier ? (supplier.phone || '') : ''
                                                    });
                                                }}
                                                style={{ flex: 1, padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                            >
                                                <option value="">-- Kein Lieferant ausgewählt --</option>
                                                {suppliers.map(s => (
                                                    <option key={s.id} value={s.id}>{s.name}</option>
                                                ))}
                                            </select>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setIsCreatingSupplier(true);
                                                    setNewSupplier({ name: '', email: '', phone: '' });
                                                }}
                                                title="Neuen Lieferanten anlegen"
                                                style={{
                                                    padding: '0 12px',
                                                    borderRadius: 'var(--radius-sm)',
                                                    border: '1px solid var(--color-primary)',
                                                    backgroundColor: 'var(--color-primary)',
                                                    color: 'white',
                                                    cursor: 'pointer',
                                                    fontSize: '18px',
                                                    fontWeight: 'bold'
                                                }}
                                            >
                                                +
                                            </button>
                                        </div>
                                    ) : (
                                        <div style={{ padding: 'var(--spacing-md)', border: '1px solid var(--color-primary)', borderRadius: 'var(--radius-md)', backgroundColor: 'rgba(37, 99, 235, 0.05)' }}>
                                            <div style={{ marginBottom: '8px' }}>
                                                <input
                                                    type="text"
                                                    placeholder="Name des Lieferanten *"
                                                    value={newSupplier.name}
                                                    onChange={e => setNewSupplier({ ...newSupplier, name: e.target.value })}
                                                    style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                />
                                            </div>
                                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                                                <input
                                                    type="email"
                                                    placeholder="Email"
                                                    value={newSupplier.email}
                                                    onChange={e => setNewSupplier({ ...newSupplier, email: e.target.value })}
                                                    style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                />
                                                <input
                                                    type="tel"
                                                    placeholder="Telefon (optional)"
                                                    value={newSupplier.phone}
                                                    onChange={e => setNewSupplier({ ...newSupplier, phone: e.target.value })}
                                                    style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                />
                                            </div>

                                            <button
                                                type="button"
                                                onClick={() => setShowSupplierDetails(!showSupplierDetails)}
                                                style={{ border: 'none', background: 'none', color: 'var(--color-primary)', cursor: 'pointer', fontSize: 'var(--font-size-xs)', marginBottom: '8px', padding: 0, textDecoration: 'underline' }}
                                            >
                                                {showSupplierDetails ? 'Weniger Details' : 'Mehr Details (Ansprechpartner, Web, Textvorlagen...)'}
                                            </button>

                                            {showSupplierDetails && (
                                                <div style={{ marginTop: '8px', borderTop: '1px solid rgba(0,0,0,0.1)', paddingTop: '8px' }}>
                                                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                                                        <input
                                                            type="text"
                                                            placeholder="Ansprechpartner"
                                                            value={newSupplier.contactName || ''}
                                                            onChange={e => setNewSupplier({ ...newSupplier, contactName: e.target.value })}
                                                            style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                        />
                                                        <input
                                                            type="url"
                                                            placeholder="Webseite (URL)"
                                                            value={newSupplier.url || ''}
                                                            onChange={e => setNewSupplier({ ...newSupplier, url: e.target.value })}
                                                            style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                        />
                                                    </div>
                                                    <div>
                                                        <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-xs)', fontWeight: 600 }}>Notizen zum Lieferanten</label>
                                                        {(newSupplier.notes || []).map((note, idx) => (
                                                            <div key={note.id} style={{ marginBottom: '8px', padding: '8px', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-background)' }}>
                                                                <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                                                                    <textarea
                                                                        rows={2}
                                                                        value={note.text}
                                                                        onChange={e => {
                                                                            const updated = [...(newSupplier.notes || [])];
                                                                            updated[idx].text = e.target.value;
                                                                            setNewSupplier({ ...newSupplier, notes: updated });
                                                                        }}
                                                                        placeholder="Notiz eingeben..."
                                                                        style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit' }}
                                                                    />
                                                                    <button
                                                                        type="button"
                                                                        onClick={() => {
                                                                            const updated = (newSupplier.notes || []).filter((_, i) => i !== idx);
                                                                            setNewSupplier({ ...newSupplier, notes: updated });
                                                                        }}
                                                                        style={{ background: 'none', border: 'none', color: 'var(--color-danger)', cursor: 'pointer', padding: '4px' }}
                                                                    >
                                                                        <X size={14} />
                                                                    </button>
                                                                </div>
                                                                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '4px' }}>
                                                                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                                                                        <input
                                                                            type="checkbox"
                                                                            checked={note.showOnOrderCreation}
                                                                            onChange={e => {
                                                                                const updated = [...(newSupplier.notes || [])];
                                                                                updated[idx].showOnOrderCreation = e.target.checked;
                                                                                setNewSupplier({ ...newSupplier, notes: updated });
                                                                            }}
                                                                        />
                                                                        <span style={{ fontSize: 'var(--font-size-xs)' }}>Beim Anlegen einer Bestellung anzeigen</span>
                                                                    </label>
                                                                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                                                                        <input
                                                                            type="checkbox"
                                                                            checked={note.showOnOpenOrders}
                                                                            onChange={e => {
                                                                                const updated = [...(newSupplier.notes || [])];
                                                                                updated[idx].showOnOpenOrders = e.target.checked;
                                                                                setNewSupplier({ ...newSupplier, notes: updated });
                                                                            }}
                                                                        />
                                                                        <span style={{ fontSize: 'var(--font-size-xs)' }}>Bei offenen Bestellungen anzeigen</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        ))}
                                                        <button
                                                            type="button"
                                                            onClick={() => {
                                                                const updated = [...(newSupplier.notes || []), { id: generateId(), text: '', showOnOrderCreation: false, showOnOpenOrders: false }];
                                                                setNewSupplier({ ...newSupplier, notes: updated });
                                                            }}
                                                            style={{ background: 'none', border: 'none', color: 'var(--color-primary)', fontSize: 'var(--font-size-xs)', fontWeight: 600, cursor: 'pointer', padding: 0, marginBottom: '8px' }}
                                                        >
                                                            + Weitere Notiz
                                                        </button>
                                                    </div>
                                                    <div style={{ marginBottom: '8px' }}>
                                                        <label style={{ fontSize: 'var(--font-size-xs)', fontWeight: 600 }}>Standard Email-Textvorlage</label>
                                                        <input
                                                            type="text"
                                                            placeholder="Betreff Vorlage"
                                                            value={newSupplier.emailSubjectTemplate || ''}
                                                            onChange={e => setNewSupplier({ ...newSupplier, emailSubjectTemplate: e.target.value })}
                                                            style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', marginBottom: '4px' }}
                                                        />
                                                        <textarea
                                                            placeholder="Nachricht Vorlage (Platzhalter: {product_name}, {quantity}, {unit})"
                                                            rows={3}
                                                            value={newSupplier.emailBodyTemplate || ''}
                                                            onChange={e => setNewSupplier({ ...newSupplier, emailBodyTemplate: e.target.value })}
                                                            style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit', marginBottom: '8px' }}
                                                        />
                                                    </div>
                                                </div>
                                            )}

                                            <div style={{ fontSize: '10px', color: 'var(--color-text-muted)', marginTop: '4px' }}>
                                                Lieferant wird beim Speichern des Produkts automatisch neu angelegt.
                                            </div>
                                        </div>
                                    )}
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>
                                        {(newProduct.supplierId || isCreatingSupplier) ? 'Abweichende Bestell-Email (opt.)' : 'Email-Adresse'}
                                    </label>
                                    <input
                                        type="email"
                                        placeholder={isCreatingSupplier ? "Leer lassen für Lieferanten-Email" : "bestellung@lieferant.de"}
                                        value={newProduct.emailOrderAddress || ''}
                                        onChange={e => setNewProduct({ ...newProduct, emailOrderAddress: e.target.value })}
                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                    />

                                    <div style={{ marginTop: 'var(--spacing-sm)' }}>
                                        <button
                                            type="button"
                                            onClick={() => setIsEmailTemplateOpen(!isEmailTemplateOpen)}
                                            style={{
                                                background: 'none',
                                                border: 'none',
                                                padding: 0,
                                                cursor: 'pointer',
                                                display: 'flex',
                                                alignItems: 'center',
                                                fontSize: 'var(--font-size-sm)',
                                                color: 'var(--color-primary)',
                                                fontWeight: 500
                                            }}
                                        >
                                            Standardbestelltext hinzufügen
                                            <span style={{ transform: isEmailTemplateOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s', marginLeft: '4px' }}>▼</span>
                                        </button>

                                        {isEmailTemplateOpen && (
                                            <div style={{ marginTop: 'var(--spacing-sm)', paddingLeft: 'var(--spacing-md)', borderLeft: '2px solid var(--color-border)' }}>
                                                <div style={{ marginBottom: 'var(--spacing-sm)' }}>
                                                    <label style={{ display: 'block', marginBottom: '4px', fontSize: 'var(--font-size-xs)' }}>Standard Betreff</label>
                                                    <input
                                                        type="text"
                                                        value={newProduct.emailOrderSubject || ''}
                                                        onChange={e => setNewProduct({ ...newProduct, emailOrderSubject: e.target.value })}
                                                        placeholder=""
                                                        style={{ width: '100%', padding: '6px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                    />
                                                </div>
                                                <div style={{ marginBottom: 'var(--spacing-sm)' }}>
                                                    <label style={{ display: 'block', marginBottom: '4px', fontSize: 'var(--font-size-xs)' }}>Standard Nachricht</label>
                                                    <textarea
                                                        value={newProduct.emailOrderBody || ''}
                                                        onChange={e => setNewProduct({ ...newProduct, emailOrderBody: e.target.value })}
                                                        rows={4}
                                                        placeholder=""
                                                        style={{ width: '100%', padding: '6px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit' }}
                                                    />
                                                </div>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)', marginTop: 'var(--spacing-sm)' }}>
                                                    <button
                                                        type="button"
                                                        onClick={() => setNewProduct({ ...newProduct, autoOrder: !newProduct.autoOrder })}
                                                        style={{
                                                            background: 'none',
                                                            border: 'none',
                                                            padding: 0,
                                                            cursor: 'pointer',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            color: newProduct.autoOrder ? 'var(--color-primary)' : 'var(--color-text-muted)'
                                                        }}
                                                    >
                                                        {newProduct.autoOrder ? <CheckSquare size={20} /> : <Square size={20} />}
                                                    </button>
                                                    <label
                                                        onClick={() => setNewProduct({ ...newProduct, autoOrder: !newProduct.autoOrder })}
                                                        style={{ cursor: 'pointer', fontWeight: 500, fontSize: 'var(--font-size-sm)' }}
                                                    >
                                                        Automatische Bestellung (via EmailJS)
                                                    </label>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Shop-Link / Bestell-URL</label>
                                    <input
                                        type="url"
                                        value={newProduct.orderUrl || ''}
                                        onChange={e => setNewProduct({ ...newProduct, orderUrl: e.target.value })}
                                        onBlur={e => {
                                            const val = e.target.value;
                                            if (val && !/^https?:\/\//i.test(val)) {
                                                setNewProduct({ ...newProduct, orderUrl: `https://${val}` });
                                            }
                                        }}
                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Bild URL (optional)</label>
                                    <input
                                        type="url"
                                        value={newProduct.image || ''}
                                        onChange={e => setNewProduct({ ...newProduct, image: e.target.value })}
                                        onBlur={e => {
                                            const val = e.target.value;
                                            if (val && !/^https?:\/\//i.test(val)) {
                                                setNewProduct({ ...newProduct, image: `https://${val}` });
                                            }
                                        }}
                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Standard Bestellweg</label>
                                    <div style={{ display: 'flex', gap: 'var(--spacing-lg)' }}>
                                        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)', cursor: 'pointer' }}>
                                            <input
                                                type="radio"
                                                name="preferredOrderMethod"
                                                value="email"
                                                checked={newProduct.preferredOrderMethod === 'email'}
                                                onChange={() => setNewProduct({ ...newProduct, preferredOrderMethod: 'email' })}
                                            />
                                            Email
                                        </label>
                                        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)', cursor: 'pointer' }}>
                                            <input
                                                type="radio"
                                                name="preferredOrderMethod"
                                                value="link"
                                                checked={newProduct.preferredOrderMethod === 'link'}
                                                onChange={() => setNewProduct({ ...newProduct, preferredOrderMethod: 'link' })}
                                            />
                                            Link / Shop
                                        </label>
                                        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)', cursor: 'pointer' }}>
                                            <input
                                                type="radio"
                                                name="preferredOrderMethod"
                                                value="phone"
                                                checked={newProduct.preferredOrderMethod === 'phone'}
                                                onChange={() => setNewProduct({ ...newProduct, preferredOrderMethod: 'phone' })}
                                            />
                                            Telefon
                                        </label>
                                    </div>
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Notizen</label>
                                    {(newProduct.notes || []).map((note, idx) => (
                                        <div key={note.id} style={{ marginBottom: 'var(--spacing-md)', padding: 'var(--spacing-sm)', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-md)', backgroundColor: 'var(--color-background)' }}>
                                            <div style={{ display: 'flex', position: 'relative' }}>
                                                <MessageSquare size={16} style={{ position: 'absolute', top: '10px', left: '10px', color: 'var(--color-text-muted)' }} />
                                                <textarea
                                                    rows={2}
                                                    value={note.text}
                                                    onChange={e => {
                                                        const updated = [...(newProduct.notes || [])];
                                                        updated[idx].text = e.target.value;
                                                        setNewProduct({ ...newProduct, notes: updated });
                                                    }}
                                                    placeholder="Notiz eingeben..."
                                                    style={{ width: '100%', padding: 'var(--spacing-sm) var(--spacing-sm) var(--spacing-sm) 36px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit' }}
                                                />
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        const updated = (newProduct.notes || []).filter((_, i) => i !== idx);
                                                        setNewProduct({ ...newProduct, notes: updated });
                                                    }}
                                                    style={{ background: 'none', border: 'none', color: 'var(--color-danger)', cursor: 'pointer', padding: '0 0 0 8px', alignSelf: 'flex-start', marginTop: '4px' }}
                                                >
                                                    <X size={16} />
                                                </button>
                                            </div>
                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '8px' }}>
                                                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                                                    <input
                                                        type="checkbox"
                                                        checked={note.showOnOrderCreation}
                                                        onChange={e => {
                                                            const updated = [...(newProduct.notes || [])];
                                                            updated[idx].showOnOrderCreation = e.target.checked;
                                                            setNewProduct({ ...newProduct, notes: updated });
                                                        }}
                                                    />
                                                    <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-main)' }}>Beim Anlegen einer Bestellung anzeigen</span>
                                                </label>
                                                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                                                    <input
                                                        type="checkbox"
                                                        checked={note.showOnOpenOrders}
                                                        onChange={e => {
                                                            const updated = [...(newProduct.notes || [])];
                                                            updated[idx].showOnOpenOrders = e.target.checked;
                                                            setNewProduct({ ...newProduct, notes: updated });
                                                        }}
                                                    />
                                                    <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-main)' }}>Bei offenen Bestellungen anzeigen</span>
                                                </label>
                                            </div>
                                        </div>
                                    ))}
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const updated = [...(newProduct.notes || []), { id: generateId(), text: '', showOnOrderCreation: false, showOnOpenOrders: false }];
                                            setNewProduct({ ...newProduct, notes: updated });
                                        }}
                                        style={{ display: 'flex', alignItems: 'center', gap: '4px', background: 'none', border: 'none', color: 'var(--color-primary)', fontWeight: 500, cursor: 'pointer', padding: 0 }}
                                    >
                                        <Plus size={16} /> Weitere Notiz hinzufügen
                                    </button>
                                </div>



                                <div style={{
                                    border: '1px solid var(--color-border)',
                                    borderRadius: 'var(--radius-md)',
                                    overflow: 'hidden'
                                }}>
                                    <button
                                        type="button"
                                        onClick={() => setIsInventoryDetailsOpen(!isInventoryDetailsOpen)}
                                        style={{
                                            width: '100%',
                                            padding: 'var(--spacing-md)',
                                            background: 'var(--color-background)',
                                            border: 'none',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'space-between',
                                            cursor: 'pointer',
                                            fontWeight: 500
                                        }}
                                    >
                                        Lager & Details
                                        <span style={{ transform: isInventoryDetailsOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>▼</span>
                                    </button>

                                    {isInventoryDetailsOpen && (
                                        <div style={{ padding: 'var(--spacing-md)', display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
                                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--spacing-md)' }}>
                                                <div>
                                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Kategorie</label>
                                                    {isCustomCategoryMode ? (
                                                        <div style={{ display: 'flex', gap: 'var(--spacing-sm)' }}>
                                                            <input
                                                                value={newProduct.category || ''}
                                                                onChange={e => setNewProduct({ ...newProduct, category: e.target.value })}
                                                                placeholder="Kategorie eingeben..."
                                                                autoFocus
                                                                style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                            />
                                                            <button
                                                                type="button"
                                                                onClick={() => {
                                                                    setIsCustomCategoryMode(false);
                                                                    setNewProduct({ ...newProduct, category: '' });
                                                                }}
                                                                style={{
                                                                    background: 'var(--color-background)',
                                                                    border: '1px solid var(--color-border)',
                                                                    borderRadius: 'var(--radius-sm)',
                                                                    cursor: 'pointer',
                                                                    padding: '0 var(--spacing-sm)'
                                                                }}
                                                                title="Zurück zur Auswahl"
                                                            >
                                                                <X size={18} />
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <select
                                                            value={newProduct.category || ''}
                                                            onChange={e => {
                                                                if (e.target.value === 'custom') {
                                                                    setIsCustomCategoryMode(true);
                                                                    setNewProduct({ ...newProduct, category: '' });
                                                                } else {
                                                                    setNewProduct({ ...newProduct, category: e.target.value });
                                                                }
                                                            }}
                                                            style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                        >
                                                            <option value="">-- Leer --</option>
                                                            {CATEGORIES.map(cat => (
                                                                <option key={cat} value={cat}>{cat}</option>
                                                            ))}
                                                            <option value="custom">Eigene eingeben...</option>
                                                        </select>
                                                    )}
                                                </div>
                                                <div>
                                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Einheit</label>
                                                    <input
                                                        value={newProduct.unit || ''}
                                                        onChange={e => setNewProduct({ ...newProduct, unit: e.target.value })}
                                                        placeholder="z.B. Stück"
                                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                    />
                                                </div>
                                            </div>

                                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'var(--spacing-md)' }}>
                                                <div>
                                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Bestand</label>
                                                    <input
                                                        type="number"
                                                        value={newProduct.stock || 0}
                                                        onChange={e => setNewProduct({ ...newProduct, stock: Number(e.target.value) })}
                                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                    />
                                                </div>
                                                <div>
                                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Mindestbestand</label>
                                                    <input
                                                        type="number"
                                                        value={newProduct.minStock || 0}
                                                        onChange={e => setNewProduct({ ...newProduct, minStock: Number(e.target.value) })}
                                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                    />
                                                </div>
                                                <div>
                                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Erwarteter Verbrauch</label>
                                                    <div style={{ display: 'flex', gap: '4px' }}>
                                                        <input
                                                            type="number"
                                                            step="1"
                                                            min="0"
                                                            value={newProduct.consumptionAmount || ''}
                                                            onChange={e => setNewProduct({ ...newProduct, consumptionAmount: parseFloat(e.target.value) || undefined })}
                                                            placeholder="Menge"
                                                            style={{ width: '50%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                        />
                                                        <select
                                                            value={newProduct.consumptionPeriod || ''}
                                                            onChange={e => setNewProduct({ ...newProduct, consumptionPeriod: e.target.value as 'day' | 'week' | undefined })}
                                                            style={{ width: '50%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                        >
                                                            <option value="">-- Zyklus --</option>
                                                            <option value="day">pro Tag</option>
                                                            <option value="week">pro Woche</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Preis (Netto €)</label>
                                                    <input
                                                        type="number"
                                                        step="0.01"
                                                        value={newProduct.price || ''}
                                                        onChange={e => setNewProduct({ ...newProduct, price: parseFloat(e.target.value) || 0 })}
                                                        placeholder="0.00"
                                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>

                                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--spacing-md)', marginTop: 'var(--spacing-md)' }}>
                                    <button
                                        type="button"
                                        onClick={closeModal}
                                        style={{
                                            padding: 'var(--spacing-sm) var(--spacing-md)',
                                            borderRadius: 'var(--radius-md)',
                                            border: '1px solid var(--color-border)',
                                            backgroundColor: 'transparent',
                                            color: 'var(--color-text-main)'
                                        }}
                                    >
                                        Abbrechen
                                    </button>
                                    <button
                                        type="submit"
                                        style={{
                                            padding: 'var(--spacing-sm) var(--spacing-md)',
                                            borderRadius: 'var(--radius-md)',
                                            border: 'none',
                                            backgroundColor: 'var(--color-primary)',
                                            color: 'white'
                                        }}
                                    >
                                        {isLoading ? 'Speichert...' : 'Speichern'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )
            }

            {/* Delete Confirmation Modal */}
            {
                deleteConfirmId && (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.5)',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        zIndex: 1200
                    }}>
                        <div style={{
                            backgroundColor: 'var(--color-surface)',
                            padding: 'var(--spacing-xl)',
                            borderRadius: 'var(--radius-lg)',
                            width: '100%',
                            maxWidth: '400px',
                            boxShadow: 'var(--shadow-lg)',
                            textAlign: 'center'
                        }}>
                            <h3 style={{ marginTop: 0 }}>Produkt löschen?</h3>
                            <p style={{ color: 'var(--color-text-muted)', marginBottom: 'var(--spacing-lg)' }}>
                                Möchten Sie dieses Produkt wirklich unwiderruflich löschen?
                            </p>
                            <div style={{ display: 'flex', justifyContent: 'center', gap: 'var(--spacing-md)' }}>
                                <button
                                    onClick={() => setDeleteConfirmId(null)}
                                    style={{
                                        padding: 'var(--spacing-sm) var(--spacing-md)',
                                        borderRadius: 'var(--radius-md)',
                                        border: '1px solid var(--color-border)',
                                        backgroundColor: 'transparent',
                                        cursor: 'pointer'
                                    }}
                                >
                                    Abbrechen
                                </button>
                                <button
                                    onClick={confirmDelete}
                                    disabled={isLoading}
                                    style={{
                                        padding: 'var(--spacing-sm) var(--spacing-md)',
                                        borderRadius: 'var(--radius-md)',
                                        border: 'none',
                                        backgroundColor: 'var(--color-danger)',
                                        color: 'white',
                                        cursor: 'pointer',
                                        opacity: isLoading ? 0.7 : 1
                                    }}
                                >
                                    {isLoading ? 'Löscht...' : 'Ja, löschen'}
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {
                isOrderModalOpen && orderCart.length > 0 && ((selectedProductForOrder) => (
                    <div style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.5)',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        zIndex: 1000
                    }}>
                        <div style={{
                            backgroundColor: 'var(--color-surface)',
                            padding: 'var(--spacing-xl)',
                            borderRadius: 'var(--radius-lg)',
                            width: '100%',
                            maxWidth: '400px',
                            boxShadow: 'var(--shadow-lg)',
                            maxHeight: '90vh', // Ensure it doesn't overflow screen
                            overflowY: 'auto'  // Allow scrolling
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-lg)' }}>
                                <h3 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>Bestellung aufgeben</h3>
                                <button onClick={() => setIsOrderModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                                    <X size={24} />
                                </button>
                            </div>

                            <form onSubmit={handleCreateOrder} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
                                <div>
                                    <h4 style={{ margin: '0 0 var(--spacing-sm) 0', color: 'var(--color-primary)' }}>Bestellübersicht</h4>
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: 'var(--spacing-md)' }}>
                                        {orderCart.map((item, index) => (
                                            <div key={item.product.id} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                <div style={{ flex: 1, fontWeight: 500, fontSize: 'var(--font-size-md)' }}>{item.product.name} ({item.product.unit})</div>
                                                <input 
                                                    type="number" 
                                                    min="1" 
                                                    value={item.quantity} 
                                                    onChange={e => updateCartQuantity(index, Number(e.target.value))}
                                                    style={{ width: '60px', padding: '6px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontSize: 'var(--font-size-md)' }} 
                                                />
                                                {index > 0 && (
                                                    <button type="button" onClick={() => removeFromCart(index)} style={{ background: 'none', border: 'none', color: 'var(--color-danger)', cursor: 'pointer', padding: '4px' }}>
                                                        <Trash2 size={18} />
                                                    </button>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                    
                                    {(() => {
                                        const supplierId = selectedProductForOrder.supplierId;
                                        if (!supplierId) return null;
                                        const suggestions = products.filter(p => p.supplierId === supplierId && !orderCart.some(c => c.product.id === p.id));
                                        if (suggestions.length === 0) return null;
                                        return (
                                            <div style={{ padding: '12px', backgroundColor: 'var(--color-background)', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                                                <h5 style={{ margin: '0 0 10px 0', fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>Weitere Produkte vom Lieferanten hinzufügen:</h5>
                                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                                                    {suggestions.map(p => (
                                                        <button 
                                                            key={p.id} 
                                                            type="button"
                                                            onClick={() => addToCart(p)}
                                                            style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 10px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface)', fontSize: 'var(--font-size-xs)', cursor: 'pointer', color: 'var(--color-text-main)' }}
                                                        >
                                                            <Plus size={14} /> {p.name}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        );
                                    })()}
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Bestelldatum</label>
                                    <input
                                        type="date"
                                        required
                                        value={orderDate}
                                        onChange={e => setOrderDate(e.target.value)}
                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                    />
                                </div>

                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>Notizen</label>
                                    <textarea
                                        rows={3}
                                        value={orderNotes}
                                        onChange={e => setOrderNotes(e.target.value)}
                                        placeholder="Optionale Notizen zur Bestellung..."
                                        style={{ width: '100%', padding: 'var(--spacing-sm)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit' }}
                                    />
                                </div>



                                {/* Product Note Warning */}
                                {(() => {
                                    if (selectedProductForOrder.notes && selectedProductForOrder.notes.length > 0) {
                                        return selectedProductForOrder.notes.filter(n => n.showOnOrderCreation).map(n => (
                                            <div key={n.id} style={{ backgroundColor: '#fff3cd', color: '#856404', padding: '12px', borderRadius: 'var(--radius-md)', marginBottom: 'var(--spacing-md)', border: '1px solid #ffeeba', display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                                                <AlertTriangle size={20} style={{ flexShrink: 0, marginTop: '2px' }} />
                                                <div>
                                                    <strong>Wichtige Produktnotiz:</strong><br />
                                                    {n.text}
                                                </div>
                                            </div>
                                        ));
                                    }
                                    return null;
                                })()}

                                {/* Supplier Note Warning */}
                                {(() => {
                                    const supplier = suppliers.find(s => s.id === selectedProductForOrder.supplierId);
                                    if (supplier?.notes && supplier.notes.length > 0) {
                                        return supplier.notes.filter(n => n.showOnOrderCreation).map(n => (
                                            <div key={n.id} style={{ backgroundColor: '#fff3cd', color: '#856404', padding: '12px', borderRadius: 'var(--radius-md)', marginBottom: 'var(--spacing-md)', border: '1px solid #ffeeba', display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                                                <AlertTriangle size={20} style={{ flexShrink: 0, marginTop: '2px' }} />
                                                <div>
                                                    <strong>Wichtige Lieferantennotiz:</strong><br />
                                                    {n.text}
                                                </div>
                                            </div>
                                        ));
                                    }
                                    return null;
                                })()}

                                {/* Supplier Documents */}
                                {(() => {
                                    const supplier = suppliers.find(s => s.id === selectedProductForOrder.supplierId);
                                    if (supplier && supplier.documents && supplier.documents.length > 0) {
                                        return (
                                            <div style={{
                                                backgroundColor: 'var(--color-background)',
                                                padding: 'var(--spacing-md)',
                                                borderRadius: 'var(--radius-md)',
                                                border: '1px solid var(--color-border)',
                                                marginBottom: 'var(--spacing-md)'
                                            }}>
                                                <label style={{ display: 'block', marginBottom: 'var(--spacing-sm)', fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                                                    Lieferanten-Dokumente:
                                                </label>
                                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                                    {supplier.documents.map((doc, index) => (
                                                        <a
                                                            key={index}
                                                            href={doc.url}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            style={{
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                gap: '8px',
                                                                color: 'var(--color-primary)',
                                                                textDecoration: 'none',
                                                                fontSize: 'var(--font-size-sm)'
                                                            }}
                                                        >
                                                            <ExternalLink size={14} />
                                                            {doc.name}
                                                            {doc.date && <span style={{ color: 'var(--color-text-muted)', fontSize: '10px' }}>({doc.date})</span>}
                                                        </a>
                                                    ))}
                                                </div>
                                            </div>
                                        );
                                    }
                                    return null;
                                })()}

                                {/* Order Methods Wrapper */}
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
                                    {selectedProductForOrder.orderUrl && (
                                        <div style={{
                                            backgroundColor: selectedProductForOrder.preferredOrderMethod === 'link' ? 'rgba(37, 99, 235, 0.05)' : 'var(--color-background)',
                                            padding: 'var(--spacing-md)',
                                            borderRadius: 'var(--radius-md)',
                                            border: selectedProductForOrder.preferredOrderMethod === 'link' ? '2px solid var(--color-primary)' : '1px solid var(--color-border)',
                                            order: selectedProductForOrder.preferredOrderMethod === 'link' ? -1 : 0
                                        }}>
                                            <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 'var(--spacing-sm)', fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                                                Bestelllink:
                                                {selectedProductForOrder.preferredOrderMethod === 'link' && (
                                                    <span style={{ fontSize: '10px', backgroundColor: 'var(--color-primary)', color: 'white', padding: '2px 6px', borderRadius: '10px' }}>STANDARD</span>
                                                )}
                                            </label>
                                            <a
                                                href={selectedProductForOrder.orderUrl}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                style={{
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    gap: 'var(--spacing-sm)',
                                                    padding: 'var(--spacing-sm)',
                                                    borderRadius: 'var(--radius-sm)',
                                                    border: '1px solid var(--color-border)',
                                                    backgroundColor: selectedProductForOrder.preferredOrderMethod === 'link' ? 'var(--color-primary)' : 'var(--color-surface)',
                                                    color: selectedProductForOrder.preferredOrderMethod === 'link' ? 'white' : 'var(--color-text-main)',
                                                    cursor: 'pointer',
                                                    fontWeight: 500,
                                                    textDecoration: 'none'
                                                }}
                                            >
                                                <ExternalLink size={16} />
                                                Zur Webseite
                                            </a>
                                        </div>
                                    )}

                                    {(selectedProductForOrder.supplierPhone || (suppliers.find(s => s.id === selectedProductForOrder.supplierId)?.phone)) && (
                                        <div style={{
                                            backgroundColor: selectedProductForOrder.preferredOrderMethod === 'phone' ? 'rgba(37, 99, 235, 0.05)' : 'var(--color-background)',
                                            padding: 'var(--spacing-md)',
                                            borderRadius: 'var(--radius-md)',
                                            border: selectedProductForOrder.preferredOrderMethod === 'phone' ? '2px solid var(--color-primary)' : '1px solid var(--color-border)',
                                            order: selectedProductForOrder.preferredOrderMethod === 'phone' ? -1 : 0
                                        }}>
                                            <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 'var(--spacing-sm)', fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                                                Telefonische Bestellung:
                                                {selectedProductForOrder.preferredOrderMethod === 'phone' && (
                                                    <span style={{ fontSize: '10px', backgroundColor: 'var(--color-primary)', color: 'white', padding: '2px 6px', borderRadius: '10px' }}>STANDARD</span>
                                                )}
                                            </label>
                                            <a
                                                href={`tel:${selectedProductForOrder.supplierPhone || suppliers.find(s => s.id === selectedProductForOrder.supplierId)?.phone}`}
                                                style={{
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    gap: 'var(--spacing-sm)',
                                                    padding: 'var(--spacing-sm)',
                                                    borderRadius: 'var(--radius-sm)',
                                                    border: '1px solid var(--color-border)',
                                                    backgroundColor: 'var(--color-surface)',
                                                    color: 'var(--color-text-main)',
                                                    cursor: 'pointer',
                                                    fontWeight: 500,
                                                    textDecoration: 'none'
                                                }}
                                            >
                                                <Phone size={16} />
                                                {selectedProductForOrder.supplierPhone || suppliers.find(s => s.id === selectedProductForOrder.supplierId)?.phone}
                                                <span style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>(Anrufen)</span>
                                            </a>
                                        </div>
                                    )}

                                    {selectedProductForOrder.emailOrderAddress && !selectedProductForOrder.autoOrder && (
                                        <>
                                            {selectedProductForOrder.preferredOrderMethod !== 'email' && !isOrderEmailExpanded ? (
                                                <button
                                                    type="button"
                                                    onClick={() => setIsOrderEmailExpanded(true)}
                                                    style={{
                                                        width: '100%',
                                                        padding: 'var(--spacing-md)',
                                                        borderRadius: 'var(--radius-md)',
                                                        border: '1px solid var(--color-border)',
                                                        backgroundColor: 'var(--color-background)',
                                                        color: 'var(--color-text-muted)',
                                                        cursor: 'pointer',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        gap: '8px',
                                                        fontWeight: 500
                                                    }}
                                                >
                                                    <Mail size={16} />
                                                    Email-Bestellung öffnen
                                                </button>
                                            ) : (
                                                <div style={{
                                                    backgroundColor: selectedProductForOrder.preferredOrderMethod === 'email' ? 'rgba(37, 99, 235, 0.05)' : 'var(--color-background)',
                                                    padding: 'var(--spacing-md)',
                                                    borderRadius: 'var(--radius-md)',
                                                    border: selectedProductForOrder.preferredOrderMethod === 'email' ? '2px solid var(--color-primary)' : '1px solid var(--color-border)',
                                                    order: selectedProductForOrder.preferredOrderMethod === 'email' ? -1 : 0
                                                }}>
                                                    <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 'var(--spacing-sm)', fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                                                        Email Vorschau & Bearbeitung:
                                                        {selectedProductForOrder.preferredOrderMethod === 'email' && (
                                                            <span style={{ fontSize: '10px', backgroundColor: 'var(--color-primary)', color: 'white', padding: '2px 6px', borderRadius: '10px' }}>STANDARD</span>
                                                        )}
                                                    </label>

                                                    <div style={{ marginBottom: 'var(--spacing-sm)' }}>
                                                        <label style={{ display: 'block', marginBottom: '4px', fontSize: 'var(--font-size-xs)' }}>Betreff</label>
                                                        <input
                                                            type="text"
                                                            value={emailSubject}
                                                            onChange={e => setEmailSubject(e.target.value)}
                                                            style={{ width: '100%', padding: '6px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                                        />
                                                    </div>

                                                    <div style={{ marginBottom: 'var(--spacing-sm)' }}>
                                                        <label style={{ display: 'block', marginBottom: '4px', fontSize: 'var(--font-size-xs)' }}>Nachricht</label>
                                                        <textarea
                                                            value={emailBody}
                                                            onChange={e => setEmailBody(e.target.value)}
                                                            rows={5}
                                                            style={{ width: '100%', padding: '6px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit' }}
                                                        />
                                                    </div>

                                                    <button
                                                        type="button"
                                                        onClick={() => prepareEmailLink('gmail')}
                                                        style={{
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            gap: 'var(--spacing-sm)',
                                                            padding: 'var(--spacing-sm)',
                                                            borderRadius: 'var(--radius-sm)',
                                                            border: '1px solid var(--color-border)',
                                                            backgroundColor: '#EA4335',
                                                            color: 'white',
                                                            cursor: 'pointer',
                                                            fontWeight: 500,
                                                            width: '100%'
                                                        }}
                                                    >
                                                        <Mail size={16} />
                                                        In Gmail öffnen
                                                    </button>
                                                </div>
                                            )}
                                        </>
                                    )}
                                </div>

                                {selectedProductForOrder.autoOrder && (
                                    <div style={{
                                        backgroundColor: 'var(--color-background)',
                                        padding: 'var(--spacing-md)',
                                        borderRadius: 'var(--radius-md)',
                                        border: '1px solid var(--color-border)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 'var(--spacing-sm)',
                                        color: 'var(--color-primary)'
                                    }}>
                                        <CheckSquare size={20} />
                                        <span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>
                                            Wird automatisch per EmailJS versendet
                                        </span>
                                    </div>
                                )}

                                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--spacing-md)', marginTop: 'var(--spacing-md)' }}>
                                    <button
                                        type="button"
                                        onClick={() => setIsOrderModalOpen(false)}
                                        style={{
                                            padding: 'var(--spacing-sm) var(--spacing-md)',
                                            borderRadius: 'var(--radius-md)',
                                            border: '1px solid var(--color-border)',
                                            backgroundColor: 'transparent',
                                            color: 'var(--color-text-main)'
                                        }}
                                    >
                                        Abbrechen
                                    </button>
                                    <button
                                        type="submit"
                                        style={{
                                            padding: 'var(--spacing-sm) var(--spacing-md)',
                                            borderRadius: 'var(--radius-md)',
                                            border: 'none',
                                            backgroundColor: 'var(--color-primary)',
                                            color: 'white'
                                        }}
                                    >
                                        Bestellung anlegen
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                ))(orderCart[0].product)
            }
            {/* IoT / QR Code Modal with Tabs */}
            {showIoTLink && (
                <div style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(0,0,0,0.5)',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    zIndex: 1000
                }}>
                    <div style={{
                        backgroundColor: 'var(--color-surface)',
                        padding: 'var(--spacing-xl)',
                        borderRadius: 'var(--radius-lg)',
                        width: '100%',
                        maxWidth: '600px',
                        maxHeight: '90vh',
                        overflowY: 'auto'
                    }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-md)' }}>
                            <h3 style={{ margin: 0 }}>IoT & QR Code Integration</h3>
                            <button onClick={() => setShowIoTLink(null)} style={{ border: 'none', background: 'none', cursor: 'pointer' }}><X size={24} /></button>
                        </div>

                        {/* Tabs */}
                        <div style={{ display: 'flex', borderBottom: '1px solid var(--color-border)', marginBottom: 'var(--spacing-md)' }}>
                            <button
                                onClick={() => setQrTab('api')}
                                style={{
                                    padding: '10px 16px',
                                    border: 'none',
                                    background: 'none',
                                    borderBottom: qrTab === 'api' ? '2px solid var(--color-primary)' : 'none',
                                    color: qrTab === 'api' ? 'var(--color-primary)' : 'var(--color-text-muted)',
                                    fontWeight: qrTab === 'api' ? 600 : 400,
                                    cursor: 'pointer'
                                }}
                            >
                                API / IoT Button
                            </button>
                            <button
                                onClick={() => setQrTab('order')}
                                style={{
                                    padding: '10px 16px',
                                    border: 'none',
                                    background: 'none',
                                    borderBottom: qrTab === 'order' ? '2px solid var(--color-primary)' : 'none',
                                    color: qrTab === 'order' ? 'var(--color-primary)' : 'var(--color-text-muted)',
                                    fontWeight: qrTab === 'order' ? 600 : 400,
                                    cursor: 'pointer'
                                }}
                            >
                                QR: Bestellen
                            </button>
                            <button
                                onClick={() => setQrTab('stock')}
                                style={{
                                    padding: '10px 16px',
                                    border: 'none',
                                    background: 'none',
                                    borderBottom: qrTab === 'stock' ? '2px solid var(--color-primary)' : 'none',
                                    color: qrTab === 'stock' ? 'var(--color-primary)' : 'var(--color-text-muted)',
                                    fontWeight: qrTab === 'stock' ? 600 : 400,
                                    cursor: 'pointer'
                                }}
                            >
                                QR: Bestand
                            </button>
                        </div>

                        {/* Tab Content */}
                        {qrTab === 'api' && (
                            <>
                                {showIoTLink.curl ? (
                                    <>
                                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', marginBottom: 'var(--spacing-md)' }}>
                                            Dieser API-Endpunkt erzeugt eine offene Bestellung für <strong>{showIoTLink.product.name}</strong>.
                                            Ideal für IoT-Buttons (z.B. AWS IoT Button, flic.io) oder Skripte.
                                        </p>

                                        <div style={{ marginBottom: 'var(--spacing-md)' }}>
                                            <div style={{ fontWeight: 600, marginBottom: '4px' }}>CURL (Linux/Mac)</div>
                                            <div style={{ backgroundColor: '#1e1e1e', color: '#d4d4d4', padding: '12px', borderRadius: '4px', overflowX: 'auto', fontFamily: 'monospace', fontSize: '12px' }}>
                                                {showIoTLink.curl}
                                            </div>
                                        </div>

                                        <div>
                                            <div style={{ fontWeight: 600, marginBottom: '4px' }}>PowerShell (Windows)</div>
                                            <div style={{ backgroundColor: '#012456', color: '#ffffff', padding: '12px', borderRadius: '4px', overflowX: 'auto', fontFamily: 'monospace', fontSize: '12px' }}>
                                                {showIoTLink.powershell}
                                            </div>
                                        </div>
                                    </>
                                ) : (
                                    <div>
                                        <div style={{ padding: '20px', backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: '8px', color: '#991B1B' }}>
                                            <h4 style={{ marginTop: 0 }}>Supabase ist nicht konfiguriert</h4>
                                            <p>Die IoT-Button Integration benötigt eine Supabase-Datenbank.</p>
                                            <p>Bitte konfigurieren Sie diese in den Einstellungen.</p>
                                            <p style={{ fontWeight: 'bold' }}>Die QR-Codes (siehe andere Tabs) funktionieren auch ohne Supabase!</p>
                                        </div>
                                    </div>
                                )}
                            </>
                        )}

                        {qrTab === 'order' && (
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
                                <p>Scannt diesen Code, um direkt die Bestellmaske für <strong>{showIoTLink.product.name}</strong> zu öffnen.</p>
                                <div style={{ padding: '20px', background: 'white', border: '1px solid #eee' }}>
                                    <QRCode
                                        value={`${window.location.protocol}//${window.location.host}${window.location.pathname}?action=order&id=${showIoTLink.product.id}`}
                                        size={200}
                                    />
                                </div>
                                <p style={{ fontSize: '12px', color: '#666', marginTop: '10px' }}>
                                    Funktioniert auf jedem Gerät im gleichen Netzwerk.
                                </p>
                            </div>
                        )}

                        {qrTab === 'stock' && (
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
                                <p>Scannt diesen Code, um den Bestand von <strong>{showIoTLink.product.name}</strong> zu aktualisieren.</p>
                                <div style={{ padding: '20px', background: 'white', border: '1px solid #eee' }}>
                                    <QRCode
                                        value={`${window.location.protocol}//${window.location.host}${window.location.pathname}?action=stock&id=${showIoTLink.product.id}`}
                                        size={200}
                                    />
                                </div>
                                <p style={{ fontSize: '12px', color: '#666', marginTop: '10px' }}>
                                    Öffnet direkt den Dialog zur Bestandsänderung (+/-).
                                </p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Stock Update Modal (Scan Action) */}
            {isStockUpdateModalOpen && stockUpdateProduct && (
                <div style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(0,0,0,0.5)',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    zIndex: 1200
                }}>
                    <div style={{
                        backgroundColor: 'var(--color-surface)',
                        padding: 'var(--spacing-xl)',
                        borderRadius: 'var(--radius-lg)',
                        width: '100%',
                        maxWidth: '400px',
                        boxShadow: 'var(--shadow-lg)'
                    }}>
                        <h3 style={{ marginTop: 0, marginBottom: 'var(--spacing-md)' }}>Bestand aktualisieren</h3>
                        <p style={{ marginBottom: 'var(--spacing-lg)' }}>
                            Produkt: <strong>{stockUpdateProduct.name}</strong>
                        </p>

                        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-md)', marginBottom: 'var(--spacing-xl)' }}>
                            <button
                                onClick={() => setStockUpdateValue(prev => Math.max(0, prev - 1))}
                                style={{
                                    width: '40px',
                                    height: '40px',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid var(--color-border)',
                                    background: 'var(--color-background)',
                                    fontSize: '1.2rem',
                                    cursor: 'pointer'
                                }}
                            >
                                -
                            </button>
                            <input
                                type="number"
                                value={stockUpdateValue}
                                onChange={(e) => setStockUpdateValue(parseInt(e.target.value) || 0)}
                                style={{
                                    flex: 1,
                                    textAlign: 'center',
                                    fontSize: '1.5rem',
                                    fontWeight: 'bold',
                                    border: 'none',
                                    background: 'transparent'
                                }}
                            />
                            <button
                                onClick={() => setStockUpdateValue(prev => prev + 1)}
                                style={{
                                    width: '40px',
                                    height: '40px',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid var(--color-border)',
                                    background: 'var(--color-background)',
                                    fontSize: '1.2rem',
                                    cursor: 'pointer'
                                }}
                            >
                                +
                            </button>
                        </div>

                        <div style={{ display: 'flex', gap: 'var(--spacing-md)' }}>
                            <button
                                onClick={() => setIsStockUpdateModalOpen(false)}
                                style={{
                                    flex: 1,
                                    padding: '12px',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid var(--color-border)',
                                    backgroundColor: 'white',
                                    cursor: 'pointer'
                                }}
                            >
                                Abbrechen
                            </button>
                            <button
                                onClick={() => {
                                    handleStockUpdate(stockUpdateProduct, stockUpdateValue);
                                    setIsStockUpdateModalOpen(false);
                                    setNotification({ message: 'Bestand aktualisiert!', type: 'success' });
                                }}
                                style={{
                                    flex: 1,
                                    padding: '12px',
                                    borderRadius: 'var(--radius-md)',
                                    border: 'none',
                                    backgroundColor: 'var(--color-primary)',
                                    color: 'white',
                                    fontWeight: 'bold',
                                    cursor: 'pointer'
                                }}
                            >
                                Speichern
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {
                notification && (
                    <Notification
                        message={notification.message}
                        type={notification.type}
                        onClose={() => setNotification(null)}
                    />
                )
            }
        </div >
    );
};
