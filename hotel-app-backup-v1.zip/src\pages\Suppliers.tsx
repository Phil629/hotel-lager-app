import { generateId } from "../utils";
import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Mail, Phone, Search, X, AlertTriangle } from 'lucide-react';
import type { Supplier } from '../types';
import { DataService } from '../services/data';
import { Notification, type NotificationType } from '../components/Notification';

export const Suppliers: React.FC = () => {
    const [suppliers, setSuppliers] = useState<Supplier[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
    const [supplierToDelete, setSupplierToDelete] = useState<Supplier | null>(null);
    const [notification, setNotification] = useState<{ message: string, type: NotificationType } | null>(null);

    // Form State
    const [formData, setFormData] = useState<Partial<Supplier>>({
        name: '',
        contactName: '',
        email: '',
        phone: '',
        url: '',
        notes: []
    });

    useEffect(() => {
        loadSuppliers();
    }, []);

    useEffect(() => {
        if (notification) {
            const timer = setTimeout(() => setNotification(null), 3000);
            return () => clearTimeout(timer);
        }
    }, [notification]);

    const loadSuppliers = async () => {
        const data = await DataService.getSuppliers();
        setSuppliers(data);
    };

    const handleOpenModal = (supplier?: Supplier) => {
        if (supplier) {
            setEditingSupplier(supplier);
            setFormData(supplier);
        } else {
            setEditingSupplier(null);
            setFormData({
                name: '',
                contactName: '',
                email: '',
                phone: '',
                url: '',
                notes: [],
                documents: []
            });
        }
        setIsModalOpen(true);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (!formData.name || !formData.email) {
                setNotification({ message: 'Name und Email sind Pflichtfelder.', type: 'error' });
                return;
            }

            const supplierToSave: Supplier = {
                id: editingSupplier ? editingSupplier.id : generateId(),
                name: formData.name,
                contactName: formData.contactName,
                email: formData.email,
                phone: formData.phone,
                url: formData.url,
                notes: formData.notes,
                documents: formData.documents || []
            } as Supplier;

            await DataService.saveSupplier(supplierToSave);
            setNotification({
                message: editingSupplier ? 'Lieferant aktualisiert!' : 'Lieferant erstellt!',
                type: 'success'
            });
            setIsModalOpen(false);
            loadSuppliers();
        } catch (error) {
            console.error(error);
            setNotification({ message: 'Fehler beim Speichern.', type: 'error' });
        }
    };

    const handleDelete = async (id: string) => {
        try {
            await DataService.deleteSupplier(id);
            setNotification({ message: 'Lieferant gelöscht.', type: 'success' });
            setSupplierToDelete(null);
            loadSuppliers();
        } catch (error) {
            console.error(error);
            setNotification({ message: 'Fehler beim Löschen.', type: 'error' });
        }
    };

    const filteredSuppliers = suppliers.filter(s =>
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            {notification && (
                <Notification
                    message={notification.message}
                    type={notification.type}
                    onClose={() => setNotification(null)}
                />
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-md)' }}>
                <h2 style={{ fontSize: 'var(--font-size-2xl)', margin: 0 }}>Lieferanten</h2>
                <button
                    onClick={() => handleOpenModal()}
                    style={{
                        backgroundColor: 'var(--color-primary)',
                        color: 'white',
                        border: 'none',
                        padding: '10px 20px',
                        borderRadius: 'var(--radius-md)',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontWeight: 500,
                        boxShadow: 'var(--shadow-md)'
                    }}
                >
                    <Plus size={20} /> Neuer Lieferant
                </button>
            </div>

            <div style={{ position: 'relative', marginBottom: 'var(--spacing-lg)' }}>
                <Search size={20} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-muted)' }} />
                <input
                    type="text"
                    placeholder="Lieferanten suchen..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{
                        width: '100%',
                        padding: '10px 10px 10px 40px',
                        borderRadius: 'var(--radius-md)',
                        border: '1px solid var(--color-border)',
                        fontSize: 'var(--font-size-md)',
                        backgroundColor: 'var(--color-surface)'
                    }}
                />
            </div>

            <div style={{ display: 'grid', gap: 'var(--spacing-md)' }}>
                {filteredSuppliers.map(supplier => (
                    <div key={supplier.id} style={{
                        backgroundColor: 'var(--color-surface)',
                        padding: 'var(--spacing-lg)',
                        borderRadius: 'var(--radius-lg)',
                        boxShadow: 'var(--shadow-sm)',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}>
                        <div>
                            <h3 style={{ margin: '0 0 var(--spacing-xs) 0', fontSize: 'var(--font-size-lg)' }}>{supplier.name}</h3>
                            <div style={{ display: 'flex', gap: 'var(--spacing-lg)', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>
                                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    <Mail size={14} /> {supplier.email}
                                </span>
                                {supplier.phone && (
                                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                        <Phone size={14} /> {supplier.phone}
                                    </span>
                                )}
                                {supplier.contactName && (
                                    <span>Kontakt: {supplier.contactName}</span>
                                )}
                            </div>
                            {supplier.notes && supplier.notes.length > 0 && (
                                <div style={{ marginTop: 'var(--spacing-xs)', fontSize: 'var(--font-size-sm)', fontStyle: 'italic', color: 'var(--color-text-muted)' }}>
                                    <div style={{ fontWeight: 600 }}>Notizen:</div>
                                    {supplier.notes.map(n => (
                                        <div key={n.id} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                                            <span>- {n.text}</span>
                                            <div style={{ display: 'flex', gap: '4px', fontSize: '10px' }}>
                                                {n.showOnOrderCreation && <span style={{ backgroundColor: '#e2f0d9', color: '#38761d', padding: '2px 4px', borderRadius: '4px' }}>Bestellung</span>}
                                                {n.showOnOpenOrders && <span style={{ backgroundColor: '#fff2cc', color: '#b45f06', padding: '2px 4px', borderRadius: '4px' }}>Offen</span>}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                        <div style={{ display: 'flex', gap: 'var(--spacing-sm)' }}>
                            <button
                                onClick={() => handleOpenModal(supplier)}
                                style={{
                                    padding: '8px',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid var(--color-border)',
                                    backgroundColor: 'transparent',
                                    cursor: 'pointer',
                                    color: 'var(--color-text-main)'
                                }}
                            >
                                <Edit2 size={16} />
                            </button>
                            <button
                                onClick={() => setSupplierToDelete(supplier)}
                                style={{
                                    padding: '8px',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid #ffe0e0',
                                    backgroundColor: '#fff5f5',
                                    cursor: 'pointer',
                                    color: '#e53935'
                                }}
                            >
                                <Trash2 size={16} />
                            </button>
                        </div>
                    </div>
                ))}

                {filteredSuppliers.length === 0 && (
                    <div style={{ textAlign: 'center', padding: 'var(--spacing-2xl)', color: 'var(--color-text-muted)' }}>
                        Keine Lieferanten gefunden.
                    </div>
                )}
            </div>

            {isModalOpen && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
                    backgroundColor: 'rgba(0,0,0,0.5)',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000
                }}>
                    <div style={{
                        backgroundColor: 'var(--color-surface)',
                        padding: 'var(--spacing-xl)',
                        borderRadius: 'var(--radius-lg)',
                        width: '100%',
                        maxWidth: '500px',
                        maxHeight: '90vh',
                        overflowY: 'auto',
                        boxShadow: 'var(--shadow-lg)'
                    }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--spacing-lg)' }}>
                            <h3 style={{ margin: 0 }}>{editingSupplier ? 'Lieferant bearbeiten' : 'Neuer Lieferant'}</h3>
                            <button onClick={() => setIsModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                                <X size={24} />
                            </button>
                        </div>

                        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-md)' }}>
                            <div>
                                <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Firmenname *</label>
                                <input
                                    type="text"
                                    value={formData.name}
                                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                                    style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                    required
                                />
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--spacing-md)' }}>
                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Ansprechpartner</label>
                                    <input
                                        type="text"
                                        value={formData.contactName || ''}
                                        onChange={e => setFormData({ ...formData, contactName: e.target.value })}
                                        style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                    />
                                </div>
                                <div>
                                    <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Telefon</label>
                                    <input
                                        type="tel"
                                        value={formData.phone || ''}
                                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                                        style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                    />
                                </div>
                            </div>

                            <div>
                                <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Email Adresse (Bestellung) *</label>
                                <input
                                    type="email"
                                    value={formData.email}
                                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                                    style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                    required
                                />
                            </div>

                            <div>
                                <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Webseite / Link</label>
                                <input
                                    type="url"
                                    value={formData.url || ''}
                                    onChange={e => setFormData({ ...formData, url: e.target.value })}
                                    style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                    placeholder="https://"
                                />
                            </div>

                            <div>
                                <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Notizen zum Lieferanten</label>
                                {(formData.notes || []).map((note, idx) => (
                                    <div key={note.id} style={{ marginBottom: '8px', padding: '8px', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-background)' }}>
                                        <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                                            <textarea
                                                rows={2}
                                                value={note.text}
                                                onChange={e => {
                                                    const updated = [...(formData.notes || [])];
                                                    updated[idx].text = e.target.value;
                                                    setFormData({ ...formData, notes: updated });
                                                }}
                                                placeholder="Notiz eingeben..."
                                                style={{ width: '100%', padding: '8px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)', fontFamily: 'inherit' }}
                                            />
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    const updated = (formData.notes || []).filter((_, i) => i !== idx);
                                                    setFormData({ ...formData, notes: updated });
                                                }}
                                                style={{ background: 'none', border: 'none', color: 'var(--color-danger)', cursor: 'pointer', padding: '4px' }}
                                            >
                                                <X size={14} />
                                            </button>
                                        </div>
                                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '4px' }}>
                                            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                                                <input
                                                    type="checkbox"
                                                    checked={note.showOnOrderCreation}
                                                    onChange={e => {
                                                        const updated = [...(formData.notes || [])];
                                                        updated[idx].showOnOrderCreation = e.target.checked;
                                                        setFormData({ ...formData, notes: updated });
                                                    }}
                                                />
                                                <span style={{ fontSize: 'var(--font-size-sm)' }}>Beim Anlegen einer Bestellung anzeigen</span>
                                            </label>
                                            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                                                <input
                                                    type="checkbox"
                                                    checked={note.showOnOpenOrders}
                                                    onChange={e => {
                                                        const updated = [...(formData.notes || [])];
                                                        updated[idx].showOnOpenOrders = e.target.checked;
                                                        setFormData({ ...formData, notes: updated });
                                                    }}
                                                />
                                                <span style={{ fontSize: 'var(--font-size-sm)' }}>Bei offenen Bestellungen anzeigen</span>
                                            </label>
                                        </div>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    onClick={() => {
                                        const updated = [...(formData.notes || []), { id: generateId(), text: '', showOnOrderCreation: false, showOnOpenOrders: false }];
                                        setFormData({ ...formData, notes: updated });
                                    }}
                                    style={{ background: 'none', border: 'none', color: 'var(--color-primary)', fontSize: 'var(--font-size-sm)', fontWeight: 600, cursor: 'pointer', padding: 0, marginBottom: '8px' }}
                                >
                                    + Weitere Notiz
                                </button>
                            </div>

                            {/* Documents Section */}
                            <div>
                                <label style={{ display: 'block', marginBottom: 'var(--spacing-xs)', fontWeight: 500 }}>Dokumente / Dateilinks</label>
                                <div style={{ marginBottom: '10px' }}>
                                    {formData.documents?.map((doc, index) => (
                                        <div key={index} style={{
                                            display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px',
                                            padding: '8px', backgroundColor: 'var(--color-background)', borderRadius: 'var(--radius-md)'
                                        }}>
                                            <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                                                <a href={doc.url} target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none', color: 'var(--color-primary)', fontWeight: 500 }}>
                                                    📄 {doc.name}
                                                </a>
                                                {doc.date && (
                                                    <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                                                        Hochgeladen: {new Date(doc.date).toLocaleDateString('de-DE')}
                                                    </span>
                                                )}
                                            </div>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    const newDocs = [...(formData.documents || [])];
                                                    newDocs.splice(index, 1);
                                                    setFormData({ ...formData, documents: newDocs });
                                                }}
                                                style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--color-danger)' }}
                                            >
                                                <X size={16} />
                                            </button>
                                        </div>
                                    ))}
                                </div>

                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                    <div style={{ display: 'flex', gap: '8px' }}>
                                        <input
                                            type="text"
                                            placeholder="Dokument-Name"
                                            id="newDocName"
                                            style={{ flex: 1, padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                        />
                                        <div style={{ position: 'relative', flex: 2 }}>
                                            <input
                                                type="file"
                                                id="fileUpload"
                                                accept="application/pdf,image/*"
                                                style={{ display: 'none' }}
                                                onChange={async (e) => {
                                                    const file = e.target.files?.[0];
                                                    const nameInput = document.getElementById('newDocName') as HTMLInputElement;

                                                    if (file) {
                                                        const btn = document.getElementById('uploadBtn') as HTMLButtonElement;
                                                        const originalText = btn.innerText;
                                                        btn.disabled = true;
                                                        btn.innerText = 'Lädt hoch...';

                                                        try {
                                                            const url = await DataService.uploadFile(file);
                                                            if (url) {
                                                                // Use file name if name input is empty
                                                                const docName = nameInput.value || file.name;
                                                                setFormData({
                                                                    ...formData,
                                                                    documents: [...(formData.documents || []), {
                                                                        name: docName,
                                                                        url: url,
                                                                        date: new Date().toISOString()
                                                                    }]
                                                                });
                                                                nameInput.value = '';
                                                            } else {
                                                                setNotification({ message: 'Supabase Storage nicht konfiguriert.', type: 'error' });
                                                            }
                                                        } catch (err) {
                                                            setNotification({ message: 'Fehler beim Hochladen.', type: 'error' });
                                                        } finally {
                                                            btn.disabled = false;
                                                            btn.innerText = originalText;
                                                            // Clear file input
                                                            e.target.value = '';
                                                        }
                                                    }
                                                }}
                                            />
                                            <button
                                                type="button"
                                                id="uploadBtn"
                                                onClick={() => document.getElementById('fileUpload')?.click()}
                                                style={{
                                                    width: '100%',
                                                    padding: '8px',
                                                    borderRadius: 'var(--radius-md)',
                                                    border: '1px solid var(--color-border)',
                                                    backgroundColor: 'white',
                                                    cursor: 'pointer',
                                                    textAlign: 'left',
                                                    color: 'var(--color-text-muted)'
                                                }}
                                            >
                                                📁 PDF / Bild hochladen...
                                            </button>
                                        </div>
                                    </div>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                        <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--color-border)' }}></div>
                                        <span style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>ODER URL</span>
                                        <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--color-border)' }}></div>
                                    </div>
                                    <div style={{ display: 'flex', gap: '8px' }}>
                                        <input
                                            type="url"
                                            placeholder="URL (https://...)"
                                            id="newDocUrl"
                                            style={{ flex: 1, padding: '8px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                        />
                                        <button
                                            type="button"
                                            onClick={() => {
                                                const nameInput = document.getElementById('newDocName') as HTMLInputElement;
                                                const urlInput = document.getElementById('newDocUrl') as HTMLInputElement;
                                                if (nameInput.value && urlInput.value) {
                                                    setFormData({
                                                        ...formData,
                                                        documents: [...(formData.documents || []), {
                                                            name: nameInput.value,
                                                            url: urlInput.value,
                                                            date: new Date().toISOString()
                                                        }]
                                                    });
                                                    nameInput.value = '';
                                                    urlInput.value = '';
                                                }
                                            }}
                                            style={{
                                                padding: '8px 12px', borderRadius: 'var(--radius-md)', border: 'none',
                                                backgroundColor: 'var(--color-secondary)', color: 'var(--color-text-main)', cursor: 'pointer'
                                            }}
                                        >
                                            <Plus size={16} /> Link hinzufügen
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--spacing-md)', marginTop: 'var(--spacing-lg)' }}>
                                <button
                                    type="button"
                                    onClick={() => setIsModalOpen(false)}
                                    style={{
                                        padding: '10px 20px',
                                        borderRadius: 'var(--radius-md)',
                                        border: '1px solid var(--color-border)',
                                        backgroundColor: 'white',
                                        cursor: 'pointer'
                                    }}
                                >
                                    Abbrechen
                                </button>
                                <button
                                    type="submit"
                                    style={{
                                        padding: '10px 20px',
                                        borderRadius: 'var(--radius-md)',
                                        border: 'none',
                                        backgroundColor: 'var(--color-primary)',
                                        color: 'white',
                                        cursor: 'pointer',
                                        fontWeight: 500
                                    }}
                                >
                                    Speichern
                                </button>
                            </div>
                        </form>
                    </div>
                </div >
            )}

            {supplierToDelete && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
                    backgroundColor: 'rgba(0,0,0,0.5)',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1100
                }}>
                    <div style={{
                        backgroundColor: 'white',
                        padding: 'var(--spacing-xl)',
                        borderRadius: 'var(--radius-lg)',
                        maxWidth: '400px',
                        width: '100%',
                        boxShadow: 'var(--shadow-lg)',
                        textAlign: 'center'
                    }}>
                        <div style={{ color: 'var(--color-danger)', marginBottom: 'var(--spacing-md)' }}>
                            <AlertTriangle size={48} style={{ margin: '0 auto' }} />
                        </div>
                        <h3 style={{ margin: '0 0 var(--spacing-sm) 0' }}>Lieferant löschen?</h3>
                        <p style={{ color: 'var(--color-text-muted)', marginBottom: 'var(--spacing-lg)' }}>
                            Möchtest du den Lieferanten <strong>{supplierToDelete.name}</strong> wirklich unwiderruflich löschen?
                        </p>
                        <div style={{ display: 'flex', gap: 'var(--spacing-md)', justifyContent: 'center' }}>
                            <button
                                onClick={() => setSupplierToDelete(null)}
                                style={{
                                    padding: 'var(--spacing-sm) var(--spacing-lg)',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid var(--color-border)',
                                    backgroundColor: 'transparent',
                                    cursor: 'pointer',
                                    fontWeight: 500
                                }}
                            >
                                Abbrechen
                            </button>
                            <button
                                onClick={() => handleDelete(supplierToDelete.id)}
                                style={{
                                    padding: 'var(--spacing-sm) var(--spacing-lg)',
                                    borderRadius: 'var(--radius-md)',
                                    border: 'none',
                                    backgroundColor: 'var(--color-danger)',
                                    color: 'white',
                                    cursor: 'pointer',
                                    fontWeight: 500
                                }}
                            >
                                Löschen
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div >
    );
};
